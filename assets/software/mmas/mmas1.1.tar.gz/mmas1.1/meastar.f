c
c       Copyright (c) 2001
c       by James Lombari, Vassar College, Poughkeepsie, NY
c       and Jessica Sawyer Warren, Rutgers University, NJ.
c
c       All rights reserved.
c
c       Redistribution and use in source and binary forms are permitted
c       provided that the above copyright notice and this paragraph are
c       duplicated in all such forms and that any documentation,
c       advertising materials, and other materials related to such
c       distribution and use acknowledge that the software was developed
c       by the authors named above.
c
c       THIS SOFTWARE IS PROVIDED ``AS IS'' AND WITHOUT ANY EXPRESS OR
c       IMPLIED WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED
c       WARRANTIES OF MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.
c
*************************************************************************
* Make Me A Star:
* This file contains a sample driver program for the makemeastar subroutine
* version 1.1
* July 19, 2001
* James Lombardi (lombardi@vassar.edu) and Jessica Sawyer Warren
*************************************************************************
      program meastar
c Example driver program for the makemeastar subroutine
      implicit none
      integer NROWS,Jr,C,verbosity,elmax,NP,el
      parameter(NROWS=2000,elmax=20)
      double precision Mremnant(NROWS),Aremnant(NROWS),Premnant(NROWS),
     &     Dremnant(NROWS),Rremnant(NROWS),ELremnant(elmax,NROWS),
     &     jremnant(NROWS)
      double precision periastron
      CHARACTER*32 parentfile(2)
      
      print *,'SAMPLE DRIVER PROGRAM FOR MAKE ME A STAR!'

***********************************************************************
* Get information from user about what stars she would like to collide:
***********************************************************************
      print *
      print *,'PARENT STARS:'
      print *,'First we need to choose which two stars to collide.'
      print *,'Included with the MMAS software package are three'
      print *,'sample data files m04.mdl, m06.mdl and m08.mdl that'
      print *,'model 0.4 solar mass, 0.6 solar mass and 0.8 solar'
      print *,'mass population II main sequence stars, respectively.'
      print *
      print *, 'Enter data file name for the more massive parent star.'
      print *, '(Some systems, including SGIs, require that you type'
      print *, 'single quotes around the filename.)'
      read *, parentfile(1)
      print *, 'Enter data file name for the second parent star.'
      read *, parentfile(2)

      print *
      print *, 'Enter the periastron separation, normalized to the sum'
      print *, 'of the parent star radii (for a headon collision, use'
      print *, 'zero here):'
      read *, periastron
      if(periastron.gt.2.2) then
         print *, 'WARNING: If the stars were to remain perfectly'
         print *, 'spherical as the approached each other, they would'
         print *, 'impact only for normalized periastron separations'
         print *, 'less than 2.  Since the stars do deform, slightly'
         print *, 'larger periastron separations can still lead to'
         print *, 'contact.  Nevertheless, the periastron separation'
         print *, 'requested seems to be rather large... please make'
         print *, 'that it is normalized to R_1 + R_2 (or modify the'
         print *, 'code to do that automatically).'
         stop
      endif

      print *,'OUTPUT:'
      print *,'Information about the thermodynamic and chemical'
      print *,'composition profiles of the remnant will be returned'
      print *,'as arrays by the subroutine makemeastar.  Having longer'
      print *,'arrays will give a more accurate model of the remnant,'
      print *,'but will take longer to calculate.'
      print *
      print *,'How long would you like these arrays to be?  (If you'
      print *,'are not sure, you could try something in the range'
      print *,'from 100 to 300, for example.)'
      read *, NP

      print *,'CHEMICAL COMPOSITION ABUNDANCES:'
      print *,'If the data files you are using for the parent stars'
      print *,'contain information about the chemical composition'
      print *,'profiles, then makemeastar can determine how these'
      print *,'elements will be distributed throughout the remnant.'
      print *,'If you choose not to follow the distribution of'
      print *,'chemical elements, the code will run significantly'
      print *,'faster.  If you choose to treat only some of the'
      print *,'available chemical abundance profiles from your parent'
      print *,'models, then it will be the last columns in the data'
      print *,'file that are ignored.'
      print *
      print *,'So, how many different chemical species do you want to'
      print *,'follow?'
      read *, el

      print *,'VERBOSITY:'
      print *, 'How verbose would you like the output to be?'
      print *, ' (Enter 0 for no output to screen,'
      print *, '        1 for limited output,'
      print *, '        2 for detailed output)'
      read *, verbosity
      
***********************************************************************
* Now that we know what collision to consider, make the call to the
* main routine:
***********************************************************************
      print *, 'About to call the makemeastar subroutine...'
      call makemeastar(periastron,parentfile,verbosity,
     &     el,NP,Mremnant,Aremnant,Premnant,Dremnant,Rremnant,
     &     ELremnant,jremnant)
      print *, 'Back from the makemeastar subroutine...'
      print *
      print *,'The entropy profile A = P/rho^(5/3), where P is pressure'
      print *,'and rho is density has been returned in the array named'
      print *,'Aremnant.  In particular, Aremnant(I) is the entropy A'
      print *,'at the enclosed mass Mremnant(I).'
      if(el.gt.0) then
         print *
      endif
      if(periastron.eq.0.d0) then
         print *
      endif
       

***********************************************************************
* Create a data file for the remnant model:
***********************************************************************
      if(periastron.eq.0.d0) then
         print *, 'Writing output file: nonrotating_remnant.mdl'
         OPEN(50,FILE='nonrotating_remnant.mdl')
         do Jr=1,NP
            WRITE(50,54) Mremnant(Jr),Aremnant(Jr),Premnant(Jr),
     $           Dremnant(Jr),Rremnant(Jr),
     &           (real(ELremnant(C,Jr)),C=1,el)
         enddo
      else
         print *, 'Writing output file: rotating_remnant.mdl'
         OPEN(50,FILE='rotating_remnant.mdl')
         do Jr=1,NP
            WRITE(50,54) Mremnant(Jr),Aremnant(Jr),Premnant(Jr),
     $           Dremnant(Jr),Rremnant(Jr),
     &           (real(ELremnant(C,Jr)),C=1,el),jremnant(Jr)
c            WRITE(50,54) Mremnant(Jr),Rremnant(Jr),
c     $           Aremnant(Jr),jremnant(Jr),
c     $           (real(ELremnant(C,Jr)),C=1,el)
         enddo
      endif    
      CLOSE(50)
 54   FORMAT(E13.7,25(1X,E14.8))
      end
