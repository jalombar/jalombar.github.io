c
c       Copyright (c) 2001
c       by James Lombari, Vassar College, Poughkeepsie, NY
c       and Jessica Sawyer Warren, Rutgers University, NJ.
c       All rights reserved.
c
c       Redistribution and use in source and binary forms are permitted
c       provided that the above copyright notice and this paragraph are
c       duplicated in all such forms and that any documentation,
c       advertising materials, and other materials related to such
c       distribution and use acknowledge that the software was developed
c       by the authors named above.
c
c       THIS SOFTWARE IS PROVIDED ``AS IS'' AND WITHOUT ANY EXPRESS OR
c       IMPLIED WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED
c       WARRANTIES OF MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.
c
*************************************************************************
* Make Me A Star:
* This file contains the main subroutine makemeastar
* version 1.1
* July 19, 2001
* James Lombardi (lombardi@vassar.edu) and Jessica Sawyer Warren
*************************************************************************
      SUBROUTINE makemeastar(peri,parentfile,
     &     verboseness,numberOfChemicalElements,
     $     NumOutLines,Mremnant,Aremnant,Premnant,
     &     Dremnant,Rremnant,ELremnant,jremnant)
**********************************************************************
* Input:
*     periastron = r_p / (R_1+R_2), where r_p is the periastron separation of
*        the (parabolic) orbits, and R_1 and R_2 are the radii of the parent
*        stars when isolated.  Therefore, r_p=0 for a headon collision and
*        increases as the impact parameter increases.
*     parentfile = ARRAY of character strings for input file names, so ...
*        parentfile(1)=Name of data file for more massive parent star (star 1)
*        parentfile(2)=Name of data file for less massive parent star (star 2)
*     verboseness = an integer that sets how talkative the routines should be
*        verboseness=0 : no output
*        verboseness=1 : limited output
*        verboseness=2 : detailed output
*     el = an integer stating how many chemical abundances will be treated
*        (information on the parent abundance profiles must of course be
*         provided in parentfile(1) and parentfile(2))
*     NumOutLines = desired number of rows in the outputted remnant profiles
* Output:
*     Mremnant = an array of length NumOutLines which gives enclosed mass
*     Premnant = an array of length NumOutLines for pressure profile
*     Dremnant = an array of length NumOutLines for density profile
*     Rremnant = an array of length NumOutLines for radius profile
*     ELremnant = an array of size (NumOutLines x numberOfChemicalElements)
*        for chemical composition profiles
*     jremnant = an array of length NumOutLines for the specific angular
*        momentum profile
**********************************************************************
* This subroutine reads in data containing enclosed mass M,          *
* pressure P, and density D (in                                      *
* cgs units), and chemical abundances of a particular star.  It will *
* calculate the "entropy" A from P and D, and call                   *
* subroutines SORT, PROFILE, ENERGY, LOSEMASS, and SHOCK.            *
*     ~J.E.S. and J.C.L                                              *
**********************************************************************

      IMPLICIT NONE

* params.h contains declarations and values for N, NROWS, pi, G,
* Msun, Rsun, Mto,& Rto.  USE CGS UNITS!!!

      INCLUDE 'params.h'
      integer verbosity,NP,NumOutLines,verboseness
      double precision peri
      INTEGER Jpmax(N),I,K,C,
     &     JJ,Pmax(N),Jr,Jrmax
      DOUBLE PRECISION Mp(NROWS,N),Ap(NROWS,N),Rp(NROWS,N),Pp(NROWS,N),
     &     Dp(NROWS,N),Aptry(N),TotE(N),W,As(NROWS,N)
      DOUBLE PRECISION ELp(NROWS,elmax,N),
     &     ELm(NROWS,elmax,N)
      DOUBLE PRECISION Mr(NROWS),Ar(NROWS),ELr(NROWS,elmax),P(NROWS),
     &     D(NROWS),R(NROWS)
      DOUBLE PRECISION Mremnant(NumOutLines),Aremnant(NumOutLines),
     &     ELremnant(elmax,NumOutLines),
     &     Premnant(NumOutLines), Dremnant(NumOutLines),
     &     Rremnant(NumOutlines),jremnant(NumOutLines)
      DOUBLE PRECISION INTlow,INThigh,NEWINT,ZBRENT3,DELNRG,
     &    periastron,TotErem,Jtot,TotJrem,MLsfrac,propcoeff,atanh
      CHARACTER*32 parentfile(N)
      COMMON/NRG/TotE,TotErem
      COMMON/NEWINFO/ELp,Mp,Rp,Pmax,ELm
      COMMON/NEWENT/Jpmax,Ap,Dp,As
      COMMON/REMNANT/Mr,Ar,ELr,Jrmax,Jr,NP
      COMMON/VARIABLES/P,D,R
      COMMON/PERI/periastron
      COMMON/MASSLOSS/MLsfrac
      COMMON/verbiage/verbosity
      EXTERNAL ZBRENT3,DELNRG
      logical alreadyfudged
      integer numberOfChemicalElements
      common/numel/el

* duplicate (or nearly duplicate) the values of some of the input variables so
* that they can be passed through common blocks:
      NP=NumOutLines-1
      verbosity=verboseness
      el=numberOfChemicalElements

      if(el.GT.elmax) then
         print *,'ERROR: Increase elmax in params.h to at least',el
         stop
      endif
      if(NumOutLines+1.GT.NROWS) then
         print *,'ERROR: Increase NROWS in params.h to at least',
     $        NumOutLines+1
         print *,'You may also have to change NROWS, or its'
         print *,'equivalent, in your driver program.'
         print *,'Current value of NROWS=',NROWS
         stop
      endif

      if(verbosity.ge.1) print *,
     &     'Entering MAKEMEASTAR w/ periastron parameter r_p/(R_1+R_2)='
     &     ,peri

* read in the input files for each parent star K:
      DO K=1,N
         if(verbosity.ge.2) WRITE(6,*)
         if(verbosity.ge.1) WRITE(6,*) 'Input: ',parentfile(K)
         
         OPEN(26,FILE=parentfile(K))
         
* I refers to rows in the input data file.  JJ refers to rows where the
* enclosed mass M is increasing.   We will throw away any rows where this does
* not occur.  (Some input files may have truncated the value for the mass at
* a small enough number of digits that two rows appear to have the same
* enclosed mass M.)
         JJ=0
         DO I=1,NROWS
            READ(26,*,END=30) Mp(I,K),Rp(I,K),Pp(I,K),
     &           Dp(I,K),(ELp(I,C,K), C=1,el)
            IF(Mp(I,K).GT.Mp(JJ,K) .OR. JJ.EQ.0) THEN
               JJ=JJ+1
               Mp(JJ,K)=Mp(I,K)
               Pp(JJ,K)=Pp(I,K)
               Dp(JJ,K)=Dp(I,K)
               DO C=1,el
                  ELp(JJ,C,K)=ELp(I,C,K)
               ENDDO
               Rp(JJ,K)=Rp(I,K)
            ENDIF
         ENDDO
            
 30      Jpmax(K)=JJ
         CLOSE(26)

      ENDDO

* Now we have to calculate A.

      DO K=1,N
         if(verbosity.ge.2) WRITE(6,*)

         alreadyfudged=.false.
         DO I=1,Jpmax(K)
            Aptry(K)=Pp(I,K)/Dp(I,K)**(5.d0/3.d0)

* We want to fake data for which the "entropy" A does not increase.  Therefore
* the else part of the IF statement fakes bad data.  In particular,
* the "entropy" is forced to increase ever so slightly.
            IF(Aptry(K).GT.Ap(I-1,K) .OR. I.EQ.1) THEN
               Ap(I,K)=Aptry(K)
            else
               Ap(I,K)=1.00001d0*Ap(I-1,K)
               if(.not. alreadyfudged) then
                  if(verbosity.ge.2) then
                     print *,
     &                 'Fudging A profile outside m/M_solar=',
     &                 Mp(I,K)/Msun,' in star',K
                     print *
                  endif
                  alreadyfudged=.true.
               endif
            endif
         ENDDO

         if(verbosity.ge.2) then
            print *, 'Information about star',K,':'
            WRITE(6,*) 'Jpmax(',K,')=',Jpmax(K)
            WRITE(6,*) 'Mass (in solar units)=',Mp(Jpmax(K),K)/Msun
            WRITE(6,*) 'Radius (in solar units)=',Rp(Jpmax(K),K)/Rsun
         endif

         CALL ENERGY(Mp(1,K),Pp(1,K),Dp(1,K),Rp(1,K),
     &        Jpmax(K),K)
         
      ENDDO

      if(Mp(Jpmax(2),2).gt.Mp(Jpmax(1),1))
     $     pause 'The more massive star is supposed to be first...'

c     First find mass loss for the headon collision case between these two
c     parent stars:
      periastron=0.d0
      CALL LOSEMASS

c Determine the intercept b_1 for the shock heating for the headon case
      INTlow=-0.9d0
      INThigh=0.9d0
      NEWINT=ZBRENT3(DELNRG,INTlow,INThigh,1.d-4)
      if(verbosity.ge.1) print *,
     &     'The headon collision gave an intercept b_1=',NEWINT

      if(peri.ne.0.d0) then
         periastron=peri
         if(verbosity.ge.2) print *
         if(verbosity.ge.1)
     &        print *,'WE CAN NOW TREAT THE ACTUAL PERIASTRON CASE...'
         CALL LOSEMASS
         NEWINT=NEWINT-const4*periastron*
     &        LOG10(Mp(Jpmax(1),1)/Mp(Jpmax(2),2))
         if(verbosity.ge.1)
     &        print *,'For this periastron separation, b_1=',NEWINT
      endif

      if(verbosity.ge.2) WRITE(6,*)
      if(verbosity.ge.2) WRITE(6,*) 'Starting final SHOCK'
      CALL SHOCK(NEWINT)
      if(verbosity.ge.2) then
         DO K=1,N
            print *,'central shocked A for star',K,' =',As(1,K)
            print *,'surface shocked A for star',K,' =',As(Jpmax(K),K)
            print *,'shocked A for star',K,' at last bound mass=',
     &           As(Pmax(K),K)
         ENDDO
      endif

      if(el.eq.0) then
         if(verbosity.ge.2) WRITE(6,*) 'SKIPPING THE MIXING'
      else
         DO K=1,N
            if(verbosity.ge.2) then
               WRITE(6,*)
               WRITE(6,*) 'Calculating mixing for star',K
            endif
            CALL MIX(K)
         ENDDO
      endif

* Pmax(K) comes from the LOSEMASS subroutine.

      if(verbosity.ge.2) then
         WRITE(6,*)
         WRITE(6,*) 'Starting final SORT'
      endif
      CALL SORT
      if(verbosity.ge.2) then
         WRITE(6,*) 'surface A for remnant=',Ar(Jrmax)
         WRITE(6,*) 'central A for remnant=',Ar(1)
         WRITE(6,*) 'row max for remnant (Jrmax)=',Jrmax
      endif
      
      if(verbosity.ge.2) then
         WRITE(6,*)
         WRITE(6,*) 'Starting final PROFILE'
      endif
      CALL PROFILE
      
      W=0.d0
      DO K=1,N
         W=TotE(K)+W
      ENDDO

      if(verbosity.ge.2) then      
         WRITE(6,*)
         WRITE(6,*) 'Total energy of parent stars is',W
      endif
      if(verbosity.ge.1) then
         WRITE(6,*) 'Total mass of remnant (in solar units) is',
     &        Mr(Jrmax)/Msun
         DO K=1,N
            print *, 'Radius of parent star ',K,' (in solar units)='
     &           ,Rp(Jpmax(K),K)/Rsun
            print *, 'Mass of parent star ',K,' (in solar units)='
     &           ,Mp(Jpmax(K),K)/Msun
         ENDDO
      endif
      Jtot=Mp(Jpmax(1),1)*Mp(Jpmax(2),2)*
     &     (2*G*periastron*(Rp(Jpmax(1),1)+Rp(Jpmax(2),2))/
     &     (Mp(Jpmax(1),1)+Mp(Jpmax(2),2))
     &     )**0.5d0
      if(verbosity.ge.2) print *,
     &     'Total angular momentum of parent stars is (cgs)',Jtot
      TotJrem=Jtot*(1.d0-const9*MLsfrac)
      if(verbosity.ge.2) then
         print *,'Total angular momentum of remnant is (cgs)',TotJrem
         print *, 'J_remnant/M_remnant = ',TotJrem/Mr(Jrmax)
      endif

      propcoeff=const10/
     $(3.d0/const10**1.5d0*atanh(const10**0.5d0)-3.d0/const10-1.d0)*
     $     TotJrem/Mr(Jrmax)
      DO Jr=1,Jrmax
         Mremnant(Jr)=Mr(Jr)
         Aremnant(Jr)=Ar(Jr)
         Premnant(Jr)=P(Jr)
         Dremnant(Jr)=D(Jr)
         Rremnant(Jr)=R(Jr)
         do C=1,el
* Note that the order of the arguments is different in ELremnant than it is in
* Elr.
            Elremnant(C,Jr)=ELr(Jr,C)
         enddo
         jremnant(Jr)=propcoeff*
     $        (Mr(Jr)/Mr(Jrmax))**(2.d0/3.d0)/
     &        (1.d0-const10*(Mr(Jr)/Mr(Jrmax))**(2.d0/3.d0))

      ENDDO

* If the subroutine EVOLUTION is called, the thermodynamic profiles for a
* rotating remnant are calculated using the techniques of Endal and Sofia.
* In particular, additional data files are created that
* allow an initial model to be generated for input into the YREC stellar
* evolution code.  (Since the EVOLUTION routine draws heavily on portions
* of YREC, it should not be made publicly available at this time.)
c      CALL EVOLUTION(Mr,Ar,P,D,R,ELr,Jrmax,CASE)

      if(verbosity.ge.2) print *,
     &     'DONE!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!'
      END
      
*************************************************************
*************************************************************
*************************************************************
*************************************************************
*************************************************************
*************************************************************
*************************************************************

*************************************************************
* ZBRENT minimizes the radius                               *
*************************************************************
      FUNCTION zbrent(func,x1,x2,tol)
      INTEGER ITMAX
      DOUBLE PRECISION zbrent,tol,x1,x2,func,EPS
      EXTERNAL func
      PARAMETER (ITMAX=1000,EPS=3.d-8)
      INTEGER iter
      DOUBLE PRECISION a,b,c,d,e,fa,fb,fc,p,q,r,s,tol1,xm

      a=x1
      b=x2
      fa=func(a)
      fb=func(b)
      if((fa.gt.0.d0.and.fb.gt.0.d0).or.
     &     (fa.lt.0.d0.and.fb.lt.0.d0))then
         print *
         print *,'You must be pushing the limits of this code.'
         print *,'Try letting Rup be even larger [increase the'
         print *,'size of the term being added to R(Jr-1)]'
         print *,'and see if that helps you get a model...'
         print *,'Also consider emailing lombardi@vassar.edu'
         pause 'root must be bracketed for zbrent'
      endif
      c=b
      fc=fb
      do 11 iter=1,ITMAX
        if((fb.gt.0.d0.and.fc.gt.0.d0).or.
     &        (fb.lt.0.d0.and.fc.lt.0.d0))then
          c=a
          fc=fa
          d=b-a
          e=d
        endif
        if(abs(fc).lt.abs(fb)) then
          a=b
          b=c
          c=a
          fa=fb
          fb=fc
          fc=fa
        endif
        tol1=2.d0*EPS*abs(b)+0.5d0*tol
        xm=.5d0*(c-b)
        if(abs(xm).le.tol1 .or. fb.eq.0.d0)then
          zbrent=b
          return
        endif
        if(abs(e).ge.tol1 .and. abs(fa).gt.abs(fb)) then
          s=fb/fa
          if(a.eq.c) then
            p=2.d0*xm*s
            q=1.d0-s
          else
            q=fa/fc
            r=fb/fc
            p=s*(2.d0*xm*q*(q-r)-(b-a)*(r-1.d0))
            q=(q-1.d0)*(r-1.d0)*(s-1.d0)
          endif
          if(p.gt.0.d0) q=-q
          p=abs(p)
          if(2.d0*p .lt. min(3.d0*xm*q-abs(tol1*q),abs(e*q))) then
            e=d
            d=p/q
          else
            d=xm
            e=d
          endif
        else
          d=xm
          e=d
        endif
        a=b
        fa=fb
        if(abs(d) .gt. tol1) then
          b=b+d
        else
          b=b+sign(tol1,xm)
        endif
        fb=func(b)
11    continue
      pause 'zbrent exceeding maximum iterations'
      zbrent=b
      return
      END

*************************************************************
*ZBRENT2 minimizes the pressure                             *
*************************************************************
      FUNCTION zbrent2(func,x1,x2,tol)
      INTEGER ITMAX
      DOUBLE PRECISION zbrent2,tol,x1,x2,func,EPS
      EXTERNAL func
      PARAMETER (ITMAX=100,EPS=3.d-8)
      INTEGER iter
      DOUBLE PRECISION a,b,c,d,e,fa,fb,fc,p,q,r,s,tol1,xm

      a=x1
      b=x2
      fa=func(a)
      fb=func(b)
      if((fa.gt.0.d0.and.fb.gt.0.d0).or.
     &     (fa.lt.0.d0.and.fb.lt.0.d0))then
         print *
         print *,'You must be pushing the limits of this code.'
         print *,'Try expanding the range of Pclow and Pchigh'
         print *,'and see if that helps you get a model...'
         print *,'Also consider emailing lombardi@vassar.edu'
         pause 'root must be bracketed for ... zbrent2'
      endif
      c=b
      fc=fb
      do 11 iter=1,ITMAX
        if((fb.gt.0.d0.and.fc.gt.0.d0).or.
     &        (fb.lt.0.d0.and.fc.lt.0.d0))then
          c=a
          fc=fa
          d=b-a
          e=d
        endif
        if(abs(fc).lt.abs(fb)) then
          a=b
          b=c
          c=a
          fa=fb
          fb=fc
          fc=fa
        endif
        tol1=2.d0*EPS*abs(b)+0.5d0*tol
        xm=.5d0*(c-b)
        if(abs(xm).le.tol1 .or. fb.eq.0.d0)then
          zbrent2=b
          return
        endif
        if(abs(e).ge.tol1 .and. abs(fa).gt.abs(fb)) then
          s=fb/fa
          if(a.eq.c) then
            p=2.d0*xm*s
            q=1.d0-s
          else
            q=fa/fc
            r=fb/fc
            p=s*(2.d0*xm*q*(q-r)-(b-a)*(r-1.d0))
            q=(q-1.d0)*(r-1.d0)*(s-1.d0)
          endif
          if(p.gt.0.d0) q=-q
          p=abs(p)
          if(2.d0*p .lt. min(3.d0*xm*q-abs(tol1*q),abs(e*q))) then
            e=d
            d=p/q
          else
            d=xm
            e=d
          endif
        else
          d=xm
          e=d
        endif
        a=b
        fa=fb
        if(abs(d) .gt. tol1) then
          b=b+d
        else
          b=b+sign(tol1,xm)
        endif
        fb=func(b)
11    continue
      pause 'zbrent2 exceeding maximum iterations'
      zbrent2=b
      return
      END

*************************************************************
* ZBRENT3 used to minimize delta Energy                     *
*************************************************************
      FUNCTION zbrent3(func,x1,x2,tol)
      INTEGER ITMAX
      DOUBLE PRECISION zbrent3,tol,x1,x2,func,EPS
      EXTERNAL func
      PARAMETER (ITMAX=100,EPS=3.d-8)
      INTEGER iter
      DOUBLE PRECISION a,b,c,d,e,fa,fb,fc,p,q,r,s,tol1,xm
 
      a=x1
      b=x2
      fa=func(a)
      fb=func(b)
      if((fa.gt.0.d0.and.fb.gt.0.d0).or.
     &     (fa.lt.0.d0.and.fb.lt.0.d0))then
         print *
         print *,'You must be pushing the limits of this code.'
         print *,'Try expanding the range of INTlow and INThigh'
         print *,'and see if that helps you get a model...'
         print *,'Also consider emailing lombardi@vassar.edu'
         pause 'root must be bracketed for zbrent3'
      endif
      c=b
      fc=fb
      do 11 iter=1,ITMAX
        if((fb.gt.0.d0.and.fc.gt.0.d0).or.
     &        (fb.lt.0.d0.and.fc.lt.0.d0))then
          c=a
          fc=fa
          d=b-a
          e=d
        endif
        if(abs(fc).lt.abs(fb)) then
          a=b
          b=c
          c=a
          fa=fb
          fb=fc
          fc=fa
        endif
        tol1=2.d0*EPS*abs(b)+0.5d0*tol
        xm=.5d0*(c-b)
        if(abs(xm).le.tol1 .or. fb.eq.0.d0)then
          zbrent3=b
          return
        endif
        if(abs(e).ge.tol1 .and. abs(fa).gt.abs(fb)) then
          s=fb/fa
          if(a.eq.c) then
            p=2.d0*xm*s
            q=1.d0-s
          else
            q=fa/fc
            r=fb/fc
            p=s*(2.d0*xm*q*(q-r)-(b-a)*(r-1.d0))
            q=(q-1.d0)*(r-1.d0)*(s-1.d0)
          endif
          if(p.gt.0.d0) q=-q
          p=abs(p)
          if(2.d0*p .lt. min(3.d0*xm*q-abs(tol1*q),abs(e*q))) then
            e=d
            d=p/q
          else
            d=xm
            e=d
          endif
        else
          d=xm
          e=d
        endif
        a=b
        fa=fb
        if(abs(d) .gt. tol1) then
          b=b+d
        else
          b=b+sign(tol1,xm)
        endif
        fb=func(b)
 11         continue
      pause 'zbrent3 exceeding maximum iterations'
      zbrent3=b
      return
      END
 
      FUNCTION DELNRG(INTERCEPT)

      IMPLICIT NONE
      INCLUDE 'params.h'
      INTEGER K,verbosity
      DOUBLE PRECISION W,TotE(N),TotErem,INTERCEPT,DELNRG,MLsfrac
      COMMON/NRG/TotE,TotErem
      COMMON/MASSLOSS/MLsfrac
      COMMON/verbiage/verbosity

      if(verbosity.ge.2) then
         WRITE(6,*)
         WRITE(6,*) '***minimizing to find intercept***'
      endif

      CALL SHOCK(INTERCEPT)
      CALL SORT
      CALL PROFILE

      W=0.d0
      DO K=1,N
         W=TotE(K)+W
      ENDDO

      DELNRG=TotErem/W-1.d0-const7*MLsfrac
      if(verbosity.ge.2)
     & print *,'delta energy=',DELNRG,'(we want this to become small)'

      RETURN
      END
      SUBROUTINE ENERGY(M,P,D,R,Jmax,STAR)

*************************************************************
* This routine will calculate the total energy of a star.   *
*************************************************************

      IMPLICIT NONE
      INCLUDE 'params.h'
      INTEGER J,Jmax,STAR,T,verbosity
      DOUBLE PRECISION P(NROWS),D(NROWS),M(NROWS),R(NROWS),
     &     Ei,Eg,delM,TotE(N),TotErem
      COMMON/NRG/TotE,TotErem
      COMMON/verbiage/verbosity

* A star's total energy consists of its gravitational energy, Eg,
* and its internal energy, Ei.  These are calculated for the star's
* innermost point and then numerically integrated outward.

      Ei=3.d0/2.d0*P(1)/D(1)*M(1)
      Eg=-G*(4.d0*D(1)*pi)**2.d0/15.d0*R(1)**5.d0

      T=2
      IF(R(1).EQ.0.d0) THEN
         Ei=Ei+3.d0/2.d0*P(2)/D(2)*M(2)
         Eg=Eg-G*(4.d0*D(2)*pi)**2.d0/15.d0*R(2)**5.d0
         T=3
      ENDIF

      DO J=T,Jmax
         delM=M(J)-M(J-1)
         Eg=Eg-G*delM*(M(J)/R(J)+M(J-1)/R(J-1))*0.5d0
         Ei=Ei+3.d0/4.d0*(P(J)/D(J)+P(J-1)/D(J-1))*delM
      ENDDO

      IF(STAR.GT.N) THEN
         if(verbosity.ge.2)
     &        WRITE(6,*) 'Total energy for remnant =',Eg+Ei
         TotErem=Eg+Ei
      ELSE
         if(verbosity.ge.2)
     &        WRITE(6,*) 'Total energy for star',STAR,' =',Eg+Ei
      ENDIF

* If all goes well, the Virial Theorem should hold and 2Ei+Eg=0.

      if(verbosity.ge.2) WRITE(6,*) '2Ei+Eg=',2.d0*Ei+Eg
      
      TotE(STAR)=Eg+Ei

      if(dabs((2.d0*Ei+Eg)/TotE(STAR)).gt.1d-2) then
         print *
         print *, 'WARNING ... WARNING ... WARNING'
         print *, 'virial/(total energy)=',(2.d0*Ei+Eg)/TotE(STAR)
         print *, 'which seems to be quite far away from 0.'
         print *, 'This ratio would be zero for a star in'
         print *, 'hydrostatic equilibrium.'
         if(STAR.GT.N) then
            print *,'The remnant seems to be far from equilibrium.'
            print *, 'You should probably request larger arrays'
            print *, 'for your remnant profiles.  If this does not'
            print *, 'help, consider emailing lombardi@vassar.edu'
         else
            print *, 'Parent star',STAR,' seems to be far from'
            print *, 'equilibrium.  Are you sure you the input'
            print *, 'data file for this star has a reasonably'
            print *, 'large number of rows in it?'
         endif
         pause
      endif
      
      END
      SUBROUTINE LOSEMASS

******************************************************************
* This routine will estimate the mass loss for each parent star. *
* Any data beyond what is "lost" will be ignored.                *
******************************************************************

      IMPLICIT NONE
      INCLUDE 'params.h'
      INTEGER Jpmax(N),Pmax(N),I70(N),verbosity,I90(N),I95(N),K
      DOUBLE PRECISION Mp(NROWS,N),Rp(NROWS,N),
     &     ELp(NROWS,elmax,N),
     &     MLsfrac,Dp(NROWS,N),Ap(NROWS,N),MLoseTotal,
     &     periastron,As(NROWS,N),ELm(NROWS,elmax,N),
     &     Rp70(N),Rp90(N),Rp95(N)
      COMMON/NEWINFO/ELp,Mp,Rp,Pmax,ELm
      COMMON/NEWENT/Jpmax,Ap,Dp,As
      COMMON/MASSLOSS/MLsfrac
      COMMON/PERI/periastron
      COMMON/verbiage/verbosity
      SAVE I70, Rp90, Rp95

      if(verbosity.ge.2) then
         WRITE(6,*)
         WRITE(6,*) 'Entering LOSEMASS FOR PERIASTRON=',periastron
         if(periastron.eq.0.d0)
     &        print *,'EVEN IF YOU DID NOT REQUEST A HEADON COLLISION',
     &        'WE STILL HAVE TO WORK ON THE HEADON CASE FOR A WHILE.'
      endif

      IF(N.NE.2) THEN
         print *, 'WARNING: MASS LOSS DOES NOT WORK UNLESS THERE ARE',
     &            ' TWO STARS'
         STOP
      ENDIF

* There should be no need to find the 70% radius if periastron is non-zero,
* because that should have already been done when treating the periastron=0
* case:
      if(periastron.eq.0.d0) then
         call geti70(I70,I90,I95)
         DO K=1,N
            Rp70(K)=((Mp(I70(K),K)/Mp(Jpmax(K),K)-.7d0)*Rp(I70(K)-1,K)+
     $           (.7d0-Mp(I70(K)-1,K)/Mp(Jpmax(K),K))*Rp(I70(K),K))/
     $           (Mp(I70(K),K)-Mp(I70(K)-1,K))*Mp(Jpmax(K),K)
            Rp90(K)=((Mp(I90(K),K)/Mp(Jpmax(K),K)-.9d0)*Rp(I90(K)-1,K)+
     $           (.9d0-Mp(I90(K)-1,K)/Mp(Jpmax(K),K))*Rp(I90(K),K))/
     $           (Mp(I90(K),K)-Mp(I90(K)-1,K))*Mp(Jpmax(K),K)
            Rp95(K)=((Mp(I95(K),K)/Mp(Jpmax(K),K)-.95d0)*Rp(I95(K)-1,K)+
     $           (.95d0-Mp(I95(K)-1,K)/Mp(Jpmax(K),K))*Rp(I95(K),K))/
     $           (Mp(I95(K),K)-Mp(I95(K)-1,K))*Mp(Jpmax(K),K)
        ENDDO
         if(verbosity.ge.2) then
            print *,'R_{0.7} are',Rp70(1)/Rsun,' and',
     $           Rp70(2)/Rsun,' solar radii'
            print *,'R_{0.9} are',Rp90(1)/Rsun,' and',
     $           Rp90(2)/Rsun,' solar radii'
            print *,'R_{0.95} are',Rp95(1)/Rsun,' and',
     $           Rp95(2)/Rsun,' solar radii'
         endif
      endif

* Now we calculate the mass lost.  It depends on the 
* reduced mass, the radius of the star in question, and the radii at
* a mass fractions of 70% and 90% in both stars.  The coefficient
* const1=0.21d0 comes
* from caluculating this information for a number of cases and averaging.

      MLoseTotal=
     &        const1*Mp(Jpmax(1),1)*Mp(Jpmax(2),2)*
     &        (Rp90(1)+Rp90(2))/
     &        ((Mp(Jpmax(1),1)+Mp(Jpmax(2),2))*
     &        (Rp(I70(1),1)+Rp(I70(2),2) +
     &         const2*periastron*(Rp(Jpmax(1),1)+Rp(Jpmax(2),2)) ))
      MLsfrac=MLoseTotal/(Mp(Jpmax(1),1)+Mp(Jpmax(2),2))

      if(verbosity.ge.1) print *,
     &     'Mass loss fraction =',MLsfrac,' for periastron=',periastron

      RETURN
      END

******************************************************************
******************************************************************
******************************************************************
      subroutine geti70(I70,I90,I95)

******************************************************************
* This routine finds the location in the parent inside of which  *
* 70% of the total mass is enclosed                              *
******************************************************************
      
      implicit none
      INCLUDE 'params.h'
      INTEGER I,K,Jpmax(N),Pmax(N),I70(N),I90(N),I95(N)
      DOUBLE PRECISION Mp(NROWS,N),Rp(NROWS,N),
     &     ELp(NROWS,elmax,N),
     &     Dp(NROWS,N),Ap(NROWS,N),
     &     As(NROWS,N),ELm(NROWS,elmax,N)
      COMMON/NEWINFO/ELp,Mp,Rp,Pmax,ELm
      COMMON/NEWENT/Jpmax,Ap,Dp,As

      DO K=1,N
         DO I=1,NROWS
            IF(Mp(I,K).GE.7.d-1*Mp(Jpmax(K),K)) GOTO 47
         ENDDO
 47      I70(K)=I
         DO I=I70(K)+1,NROWS
            IF(Mp(I,K).GE.9.d-1*Mp(Jpmax(K),K)) GOTO 48
         ENDDO
 48      I90(K)=I
         DO I=I90(K)+1,NROWS
            IF(Mp(I,K).GE.95.d-2*Mp(Jpmax(K),K)) GOTO 49
         ENDDO
 49      I95(K)=I
      ENDDO

      END

      SUBROUTINE MIX(K)

*****************************************************************
* This routine will model the hydrodynamic mixing of the        *
* chemical compositions                                         *
* in the parent stars, after shock heating has occurred and     *
* before mass loss takes place.                                 *
*****************************************************************

      IMPLICIT NONE
      INCLUDE 'params.h'
      INTEGER C,K,L,I,J,Jpmax(N),Max,Pmax(N),verbosity
c     integer halfway
      DOUBLE PRECISION ELp(NROWS,elmax,N),As(NROWS,N),Mp(NROWS,N),
     &     DENOM(NROWS),CONTRIB,dM(NROWS),alpha,
     &     F(NROWS,NROWS),dlogAdM(NROWS),ELm(NROWS,elmax,N),ELmtot,
     &     ELptot,Dp(NROWS,N),Ap(NROWS,N),Rp(NROWS,N),dlogAdMavg
      COMMON/NEWENT/Jpmax,Ap,Dp,As
      COMMON/NEWINFO/ELp,Mp,Rp,Pmax,ELm
      COMMON/verbiage/verbosity
      common/numel/el

      Max=Jpmax(K)

      DO I=2,Max-1
         dM(I)=0.5d0*(Mp(I+1,K)-Mp(I-1,K))
         dlogAdM(I)=(dlog(As(I+1,K))-dlog(As(I-1,K)))/
     &        (Mp(I+1,K)-Mp(I-1,K))
c         if(Mp(I,K).le.0.5d0*Mp(Max,K)) halfway=I
      ENDDO

      dM(1)=0.5d0*(Mp(2,K)+Mp(1,K))
      dlogAdM(1)=2.d0*(dlog(As(2,K))-dlog(As(1,K)))/(Mp(2,K)-Mp(1,K))
     &     -dlogAdM(2)
      dM(Max)=0.5d0*(Mp(Max,K)-Mp(Max-1,K))
      dlogAdM(Max)=2.d0*(dlog(As(Max,K))-dlog(As(Max-1,K)))/
     &     (Mp(Max,K)-Mp(Max-1,K))-dlogAdM(Max-1)

      dlogAdMavg=0
c      dlogAdMrms=0
      do I=1,Max
         dlogAdMavg=dlogAdMavg+dlogAdM(I)*dM(I)
c         dlogAdMrms=dlogAdMrms+dlogAdM(I)**2*dM(I)
      enddo
c
c Since we don'd divide dlogAdMavg by Mp(Max,K), we are actually calculating M times the derivative of ln A with respect to m, which is what we need to get alpha

c      dlogAdMavg=dlogAdMavg
c      dlogAdMrms=(dlogAdMrms/Mp(Max,K))**0.5

c      alphaold=-20.d0*(dAdM(halfway)*Mp(Max,K)/As(halfway,K))**2.d0
      alpha=-const8*dlogAdMavg**2.d0

      if(verbosity.ge.2) then
c      print *,'halfway=',halfway,' alphaold=',alphaold
         print *,'Mp(Max,K)=',Mp(Max,K)
         print *,'dlogAdMavg=',dlogAdMavg,', alpha from paper=',-alpha
c Note that the alpha in the paper has the opposite sign from the alpha in
c this code
c      print *,'dlogAdMrms=',dlogAdMrms
      endif

      DO I=1,Max
         DENOM(I)=0.d0
         DO J=1,Max
            F(J,I)=exp(alpha*((Mp(J,K)-Mp(I,K))/Mp(Max,K))**2.d0)
     &            +exp(alpha*((Mp(J,K)+Mp(I,K))/Mp(Max,K))**2.d0)
     &            +exp(alpha*((2.d0*Mp(Max,K)-Mp(J,K)
     &                                 -Mp(I,K))/Mp(Max,K))**2.d0)
            DENOM(I)=DENOM(I)+dM(J)*F(J,I)
         ENDDO
      ENDDO

      DO I=1,Max
         DENOM(I)=dM(I)/DENOM(I)
      ENDDO

      ELptot=0.d0
      ELmtot=0.d0

      DO C=1,el
         DO L=1,Max
            CONTRIB=0.d0
            DO I=1,Max
               CONTRIB=CONTRIB+ELp(I,C,K)*F(I,L)*DENOM(I)
            ENDDO
            ELm(L,C,K)=CONTRIB
            ELptot=ELptot+ELp(L,C,K)*dM(L)
            ELmtot=ELmtot+ELm(L,C,K)*dM(L)
         ENDDO
         if(verbosity.ge.2) WRITE(6,*) 'Element:',C

         IF((ELptot-ELmtot)/ELptot.GT.1.d-6) THEN
            WRITE(6,*) 'WARNING!!  Mass may NOT be conserved!'
            WRITE(6,*) 'ELptot=',ELptot,' ELmtot=',ELmtot
         ENDIF

      ENDDO

      RETURN
      END

      SUBROUTINE PROFILE

********************************************************************
* Given as input the remnant file made by SORT with M, A, chemical *
* data, this subroutine will find values for the remnant's         *
* pressure,  density, and radius.                                  *
********************************************************************

* All units are cgs.

* Define variables: ZBRENT2 is a slight modification of the root-finding
* function ZBRENT from Numerical Recipes.
* Pclow & Pchigh are lower and upper limits for the guess of the central
* pressure Pcntr

      IMPLICIT NONE
      INCLUDE 'params.h'
      INTEGER Jr,Jrmax,STAR,NP,verbosity
      DOUBLE PRECISION Pcntr,Pclow,Pchigh,Psurf
      DOUBLE PRECISION Mr(NROWS),Ar(NROWS),P(NROWS),
     &     D(NROWS),R(NROWS),ELr(NROWS,elmax)
      COMMON/REMNANT/Mr,Ar,ELr,Jrmax,Jr,NP
      COMMON/VARIABLES/P,D,R
      COMMON/verbiage/verbosity
      DOUBLE PRECISION ZBRENT2,PRESSURE
      EXTERNAL PRESSURE

* Define the limits for ZBRENT2:
* These limits would have to be adjusted if you are creating remnants
* with either exceedingly low or exceedingly high central pressures...
      Pclow=0.001d0*G*Msun**2.d0/(Rsun**4.d0)
      Pchigh=3000.d0*G*Msun**2.d0/(Rsun**4.d0)

      Pcntr=ZBRENT2(PRESSURE,Pclow,Pchigh,1.d-4)
      if(verbosity.ge.2) WRITE(6,*) 'Central pressure=',Pcntr
   
*** DO NOT REMOVE THE FOLLOWING ASSIGNMENT STATEMENT - IT IS NEEDED!!***
*** ONE FINAL CALL TO PRESSURE IS NEEDED TO GET CORRECT REMNANT PROFILES!!***
      Psurf=PRESSURE(Pcntr)

      if(verbosity.ge.2) WRITE(6,*) 'Surface pressure=',Psurf
      IF(Psurf.LT.0.d0) THEN
         P(Jrmax)=0.d0
         if(verbosity.ge.2) WRITE(6,*) 'Surface pressure set to 0'
      ENDIF

      Jr=1
      STAR=N+1
      CALL ENERGY(Mr(Jr),P(Jr),D(Jr),R(Jr),Jrmax,STAR)

      END

**************************************************************
      FUNCTION PRESSURE(Pctry)

      IMPLICIT NONE
      INCLUDE 'params.h'
      INTEGER Jr,Jrmax,T,NP
      DOUBLE PRECISION dM,Pctry,Rup
      DOUBLE PRECISION Mr(NROWS),Ar(NROWS),P(NROWS),D(NROWS),
     &     R(NROWS),ELr(NROWS,elmax)
      COMMON/REMNANT/Mr,Ar,ELr,Jrmax,Jr,NP
      COMMON/VARIABLES/P,D,R
      DOUBLE PRECISION PRESSURE,ZBRENT,RADIUS
      EXTERNAL RADIUS

      T=2

      P(1)=Pctry
      D(1)=(dabs(Pctry)/Ar(1))**(3.d0/5.d0)
      R(1)=(3.d0*Mr(1)/(4.d0*pi*D(1)))**(1.d0/3.d0)
      
      IF(R(1).EQ.0.d0) THEN
         dM=Mr(2)-Mr(1)
         R(2)=(3.d0*dM/(4.d0*pi*D(1)))**(1.d0/3.d0)
         P(2)=Pctry-2.d0*pi/3.d0*G*R(2)**2.d0*D(1)**2.d0
         D(2)=(dabs(P(2))/Ar(2))**(3.d0/5.d0)
         T=3
      ENDIF

      DO Jr=T,Jrmax
         dM=Mr(Jr)-Mr(Jr-1)
         Rup=R(Jr-1)+10.d0*dM/(4.d0*pi*(R(Jr-1)**2.d0)*
     &        dabs(D(Jr-1)))
         R(Jr)=ZBRENT(RADIUS,R(Jr-1),Rup,1.d-4)
         P(Jr)=P(Jr-1)-G/(8.d0*pi)*(Mr(Jr-1)/(R(Jr-1)**4.d0)+
     &        Mr(Jr)/(R(Jr)**4.d0))*dM
         D(Jr)=(dabs(P(Jr))/Ar(Jr))**(3.d0/5.d0)
      ENDDO

      PRESSURE=P(Jrmax)

      RETURN
      END


*****************************************************************
      FUNCTION RADIUS(RJr)

      IMPLICIT NONE
      INCLUDE 'params.h'
      INTEGER Jr,Jrmax,NP
      DOUBLE PRECISION Mr(NROWS),Ar(NROWS),P(NROWS),R(NROWS)
      DOUBLE PRECISION PJr,RJr,RADIUS,ELr(NROWS,elmax),D(NROWS)
      COMMON/REMNANT/Mr,Ar,ELr,Jrmax,Jr,NP
      COMMON/VARIABLES/P,D,R

      PJr=P(Jr-1)-G/(8.d0*pi)*(Mr(Jr-1)/(R(Jr-1)**4.d0)+
     &     Mr(Jr)/(RJr**4.d0))*(Mr(Jr)-Mr(Jr-1))
      RADIUS=-RJr+R(Jr-1)+(Mr(Jr)-Mr(Jr-1))/(8.d0*pi)*
     &     ((Ar(Jr-1)/P(Jr-1))**(3.d0/5.d0)/
     &     (R(Jr-1)**2.d0)+(Ar(Jr)/PJr)**(3.d0/5.d0)/(RJr**2.d0))

      RETURN
      END






      SUBROUTINE SHOCK(INTERCEPT)

*********************************************************************
* This routine will take the parent star entropy profiles and shock *
* them, creating a new entropy profile for SORT to accept and use   *
* to calculate the remnant's entropy.                               *
*********************************************************************

      IMPLICIT NONE
      INCLUDE 'params.h'

* Mto= turn-off mass in solar units
* Rto= turn-off radius in solar units
* (The use of Mto and Rto is simply because of the chosen units for the
* intercept.)
      DOUBLE PRECISION Mto,Rto
      PARAMETER(Mto=0.8d0*Msun, Rto=0.955d0*Rsun)

      INTEGER Jpmax(N),I,Imax,K,Pmax(N),I1,I2,verbosity
      DOUBLE PRECISION Ap(NROWS,N),As(NROWS,N),Dp(NROWS,N),INTERCEPT,
     &     Mp(NROWS,N),Rp(NROWS,N),ELp(NROWS,elmax,N),INTERCEPT2,slope,
     &     MLsfrac,MLoseTotal,massoutsideofI1,massoutsideofI2,
     &     periastron,ELm(NROWS,elmax,N)
      COMMON/NEWENT/Jpmax,Ap,Dp,As
      COMMON/NEWINFO/ELp,Mp,Rp,Pmax,ELm
      COMMON/MASSLOSS/MLsfrac
      COMMON/PERI/periastron
      COMMON/verbiage/verbosity      

* The equation for the shocked entropy, As, comes from a plot of
* Log(A-Ainit) vs. Log(Arho^5/3).  The value INTERCEPT is the y-intercept
* of the linear function fitted to the plot of the data.  The variable
* "const3" is the slope of that same function.

      DO K=1,N
         Imax=Jpmax(K)
         IF(K.EQ.1) THEN
            DO I=1,Imax
               As(I,K)=Ap(I,K)+10.d0**INTERCEPT*
     &          G*Mto**(1.d0/3.d0)*Rto*
     &          (Rto**4/Mto**2/G*Ap(I,K)*Dp(I,K)**(5.d0/3.d0))**const3
            ENDDO
         ELSE
            INTERCEPT2=INTERCEPT+((const4+const5)*periastron-const6)*
     &           LOG10(Mp(Jpmax(1),1)/Mp(Jpmax(K),K))
            DO I=1,Imax
               As(I,K)=Ap(I,K)+10.d0**INTERCEPT2*
     &          G*Mto**(1.d0/3.d0)*Rto*
     &          (Rto**4/Mto**2/G*Ap(I,K)*Dp(I,K)**(5.d0/3.d0))**const3
            ENDDO
            if(verbosity.ge.2) then
               print *, 'Intercept for star 2=',INTERCEPT2
               print *, 'Intercept for star 1=',INTERCEPT
            endif
         ENDIF
      ENDDO

      MLoseTotal=MLsfrac*(Mp(Jpmax(1),1)+Mp(Jpmax(2),2))
      I1=Jpmax(1)
      massoutsideofI1=0.d0
      massoutsideofI2=0.d0
      Do while (massoutsideofI1+massoutsideofI2 .lt. MLoseTotal)
         I1=I1-1
         massoutsideofI1=massoutsideofI1 + Mp(I1+1,1) - Mp(I1,1)

         I2=Jpmax(2)
         massoutsideofI2=0.d0
         do while(As(I2,2).gt.As(I1,1))
           I2=I2-1
           massoutsideofI2=massoutsideofI2 + Mp(I2+1,2) - Mp(I2,2)
         enddo
      enddo

      Pmax(1)=I1
      Pmax(2)=I2

      if(verbosity.ge.2) then
         print *,'Pmax(1)=',Pmax(1),' Pmax(2)=',Pmax(2)
         print *,'actual mass loss fraction=',
     &        (massoutsideofI1+massoutsideofI2)/
     &        (Mp(Jpmax(1),1)+Mp(Jpmax(2),2)),
     &        ' for r_p=',periastron
      endif

      RETURN
      END

      
      SUBROUTINE SORT

******************************************************************
* This subroutine will take the parent star data                 *
* of M, A and chemical abundances.  It will create similar arrays*
* for the remnant, sorted by increasing A.  In order             *
* to keep the remnant profile smooth, we'll account for the      *
* profile derivatives.                                           *
******************************************************************

* Define the variables:

* M is the mass enclosed in a star, A is the entropic variable at
* M, and EL is the chemical abundance at M.  Ji is the Jith row in 
* the data file for a star.

      IMPLICIT NONE
      INCLUDE 'params.h'
      INTEGER Jr,Jp(N),Jrmax,K,C,Pmax(N),Jpmax(N),NP
      DOUBLE PRECISION Mp(NROWS,N),ELp(NROWS,elmax,N),As(NROWS,N)
      DOUBLE PRECISION Mr(NROWS),Ar(NROWS),ELr(NROWS,elmax),Rp(NROWS,N)
      DOUBLE PRECISION dAr,dAsdMp(N),dArdMr,dArp(N),Mtmp,dAdMtmp,
     &     Armax,MofAr(N),Chemtmp(elmax),dArtmp,Chem(elmax,N),
     &     ELm(NROWS,elmax,N),
     &     Dp(NROWS,N),Ap(NROWS,N)
      COMMON/NEWINFO/ELp,Mp,Rp,Pmax,ELm
      COMMON/NEWENT/Jpmax,Ap,Dp,As
      COMMON/REMNANT/Mr,Ar,ELr,Jrmax,Jr,NP
      LOGICAL NOTDONE
      DOUBLE PRECISION dlogAr
      common/numel/el

* The maximum entropy in the remnant should be the highest in any of
* the parents:

      Armax=0.d0
      DO K=1,N
         Armax=max(Armax,As(Pmax(K),K))
      ENDDO

c      print *,'Armax=',Armax,' Pmax(1)=',Pmax(1),' Pmax(2)=',Pmax(2)

* Initialize the rows:

      DO K=1,N
         Jp(K)=1
      ENDDO
      Jr=1

* Initialize the entropy - the first value of Ar (at the lowest Mr)
* will be the lowest entropy in any of the parent stars.

      Ar(1)=1.d30
      DO K=1,N
         Ar(1)=min(Ar(1),As(1,K))
      ENDDO

      dlogAr=(DLOG10(Armax)-DLOG10(Ar(1)))/NP

* Define the logical variable that will let the program leave the
* DO loop at the right time, and initialize dAr.

      NOTDONE=.TRUE.

      dAr=0.d0

* Begin the DO loop.

      DO WHILE (NOTDONE)

* If Ar gets to be the maximum, then we're done. (hence the IF statement
* below).

         IF(Ar(Jr).GE.0.999999d0*Armax) NOTDONE=.FALSE.

* We must do a loop over each parent star.

         DO K=1,N
            DO WHILE (As(Jp(K),K).LE.Ar(Jr) .AND. Jp(K).LE.Pmax(K))
               Jp(K)=Jp(K)+1
            ENDDO
            IF(As(Pmax(K),K).LE.Ar(Jr) .AND. 
     &           As(Pmax(K),K).GE.Ar(Jr)-1.d-06) THEN
               Jp(K)=Pmax(K)
            ENDIF

            IF(Jp(K).GE.2 .AND. Jp(K).LE.Pmax(K)) THEN
               dAsdMp(K)=(As(Jp(K),K)-As(Jp(K)-1,K))/
     &              (Mp(Jp(K),K)-Mp(Jp(K)-1,K))
               MofAr(K)=(Ar(Jr)-As(Jp(K)-1,K))*Mp(Jp(K),K)/(As(Jp(K),K)-
     &              As(Jp(K)-1,K))+(As(Jp(K),K)-Ar(Jr))*Mp(Jp(K)-1,K)/
     &              (As(Jp(K),K)-As(Jp(K)-1,K))
               dArp(K)=As(Jp(K),K)-As(Jp(K)-1,K)
               DO C=1,el
                  Chem(C,K)=(Ar(Jr)-As(Jp(K)-1,K))*ELm(Jp(K),C,K)/
     &                 (As(Jp(K),K)-As(Jp(K)-1,K))+(As(Jp(K),K)-Ar(Jr))
     &                 *ELm(Jp(K)-1,C,K)/(As(Jp(K),K)-As(Jp(K)-1,K))
               ENDDO
            ELSE IF(Jp(K).EQ.1) THEN
               dAsdMp(K)=1.d30
               DO C=1,el
                  Chem(C,K)=0.d0
               ENDDO
               dArp(K)=1.d30
               MofAr(K)=0.d0
            ELSE IF(Jp(K).GT.Pmax(K)) THEN
               dAsdMp(K)=1.d30
               DO C=1,el
                  Chem(C,K)=0.d0
               ENDDO
               dArp(K)=1.d30
               MofAr(K)=Mp(Pmax(K),K)
            ENDIF
         ENDDO

         dAdMtmp=0.d0
         DO C=1,el
            Chemtmp(C)=0.d0
         ENDDO
         Mtmp=0.d0
         dArtmp=1.d30
         DO K=1,N
            dAdMtmp=1.d0/dAsdMp(K)+dAdMtmp
            DO C=1,el
               Chemtmp(C)=Chem(C,K)/dAsdMp(K)+Chemtmp(C)
            ENDDO
            Mtmp=MofAr(K)+Mtmp
            dArtmp=1.d0*min(dArp(K),dArtmp)
         ENDDO

         dArdMr=dAdMtmp**(-1.d0)
         DO C=1,el
            ELr(Jr,C)=dArdMr*Chemtmp(C)
         ENDDO
         Mr(Jr)=Mtmp

C Rather than use the smallest reasonable dAr, which would be this
C         dAr=dArtmp
C instead we'll use a dAr which gives the desired number of lines of
C data in the output.  These lines of data will have the *logarithm*
C of the entropic variable A spaced regularly...
         dAr=10.d0**(DLOG10(Ar(Jr))+dlogAr)-Ar(Jr)

         IF(Ar(Jr)+dAr.GE.0.999999d0*Armax) THEN
            dAr=Armax-Ar(Jr)
         ENDIF       

         Jr=Jr+1
         Ar(Jr)=Ar(Jr-1)+dAr

c         print *,'Jr =', Jr, ' Ar(Jr)=',Ar(Jr), 'dAr=',dAr,
c     &        'Armax=',Armax
c         print *,'dlogAr=',dlogAr

         IF(Jr.GT.NROWS) THEN
            print *, 'WARNING!  You may need to increase NROWS in'
            print *, 'the header file.  NROWS=',NROWS
            STOP
         ENDIF

      ENDDO

      Jrmax=Jr-1

      END
*******************************************************************
      FUNCTION atanh(x)
      implicit none
      double precision x,atanh

      atanh=0.5d0*dlog( (1.d0+x)/(1.d0-x))
      return
      end
