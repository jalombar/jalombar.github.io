c       Copyright (c) 2001
c       by James Lombardi, Vassar College, Poughkeepsie, NY
c       and Jessica Sawyer Warren, Rutgers University, NJ.
c       All rights reserved.
c
c       Redistribution and use in source and binary forms are permitted
c       provided that the above copyright notice and this paragraph are
c       duplicated in all such forms and that any documentation,
c       advertising materials, and other materials related to such
c       distribution and use acknowledge that the software was developed
c       by the authors named above.
c
c       THIS SOFTWARE IS PROVIDED ``AS IS'' AND WITHOUT ANY EXPRESS OR
c       IMPLIED WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED
c       WARRANTIES OF MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.
c
*************************************************************************
* Make Me A Star:
* This file contains the main subroutine makemeastar
* version 1.2
* November 1, 2001
* James Lombardi (lombardi@vassar.edu) and Jessica Sawyer Warren
*************************************************************************
      SUBROUTINE makemeastar(peri,parentfile,
     &     verboseness,numberOfChemicalElements,
     $     NumOutLines,Mremnant,Aremnant,Premnant,
     &     Dremnant,Rremnant,ELremnant,jremnant)
**********************************************************************
* Input:
*     periastron = r_p / (R_1+R_2), where r_p is the periastron separation of
*        the (parabolic) orbits, and R_1 and R_2 are the radii of the parent
*        stars when isolated.  Therefore, r_p=0 for a headon collision and
*        increases as the impact parameter increases.
*     parentfile = ARRAY of character strings for input file names, so ...
*        parentfile(1)=Name of data file for more massive parent star (star 1)
*        parentfile(2)=Name of data file for less massive parent star (star 2)
*     verboseness = an integer that sets how talkative the routines should be
*        verboseness=0 : no output
*        verboseness=1 : limited output
*        verboseness=2 : detailed output
*     el = an integer stating how many chemical abundances will be treated
*        (information on the parent abundance profiles must of course be
*         provided in parentfile(1) and parentfile(2))
*     NumOutLines = desired number of rows in the outputted remnant profiles
* Output:
*     Mremnant = an array of length NumOutLines which gives enclosed mass
*     Premnant = an array of length NumOutLines for pressure profile
*     Dremnant = an array of length NumOutLines for density profile
*     Rremnant = an array of length NumOutLines for radius profile
*     ELremnant = an array of size (NumOutLines x numberOfChemicalElements)
*        for chemical composition profiles
*     jremnant = an array of length NumOutLines for the specific angular
*        momentum profile
**********************************************************************
* This subroutine reads in data containing enclosed mass M,          *
* pressure P, and density D (in                                      *
* cgs units), and chemical abundances of a particular star.  It will *
* calculate the "entropy" A from P and D, and call                   *
* subroutines SORT, PROFILE, ENERGY, LOSEMASS, and SHOCK.            *
*     ~J.E.S. and J.C.L                                              *
**********************************************************************

      IMPLICIT NONE

* params.h contains declarations and values for N, NROWS, pi, G,
* Msun, Rsun, Mto,& Rto.  USE CGS UNITS!!!

      INCLUDE 'params.h'
      integer verbosity,NP,NumOutLines,verboseness
      double precision peri
      INTEGER Jpmax(N),I,K,C,
     &     JJ,Pmax(N),Jr,Jrmax
      DOUBLE PRECISION Mp(NROWS,N),Ap(NROWS,N),Rp(NROWS,N),Pp(NROWS,N),
     &     Dp(NROWS,N),Aptry(N),TotE(N),W,As(NROWS,N)
      DOUBLE PRECISION ELp(NROWS,elmax,N),
     &     ELm(NROWS,elmax,N)
      DOUBLE PRECISION Mr(NROWS),Ar(NROWS),ELr(NROWS,elmax),P(NROWS),
     &     D(NROWS),R(NROWS)
      DOUBLE PRECISION Mremnant(NROWS),Aremnant(NROWS),
     &     ELremnant(elmax,NROWS),
     &     Premnant(NROWS), Dremnant(NROWS),
     &     Rremnant(NROWS),jremnant(NROWS)
      DOUBLE PRECISION INTlow,INThigh,NEWINT,ZBRENT3,DELNRG,
     &    periastron,TotErem,Jtot,TotJrem,MLsfrac,propcoeff
      DOUBLE PRECISION xb1(3),xb2(3)
      integer nb
      CHARACTER*32 parentfile(N)
      COMMON/NRG/TotE,TotErem
      COMMON/NEWINFO/ELp,Mp,Rp,Pmax,ELm
      COMMON/NEWENT/Jpmax,Ap,Dp,As
      COMMON/REMNANT/Mr,Ar,ELr,Jrmax,Jr,NP
      COMMON/VARIABLES/P,D,R
      COMMON/PERI/periastron
      COMMON/MASSLOSS/MLsfrac
      COMMON/verbiage/verbosity
      EXTERNAL ZBRENT3,DELNRG
      logical alreadyfudged
      integer numberOfChemicalElements
      integer throwaway,Jrtransition
      common/numel/el
      double precision scaledJtot,Jtotin,unscaledJtotout(NROWS),
     $     jtry,disp,
     $     mtransition
      double precision cs,jcs,jkepler,jcspower,jkeplerpower,mpower
      double precision jtryin(NROWS),jtryout(NROWS),k2,k3,diff
      character*16 OUTFN
      
* duplicate (or nearly duplicate) the values of some of the input variables so
* that they can be passed through common blocks:
      NP=NumOutLines-1
      verbosity=verboseness
      el=numberOfChemicalElements

      if(verbosity.ge.2) then
         print *, 'Here are the values of the constants being used:'
         print *, 'c_1=',const1
         print *, 'c_2=',const2
         print *, 'c_3=',const3
         print *, 'c_4=',const4
         print *, 'c_5=',const5
         print *, 'c_6=',const6
         print *, 'c_7=',const7
         print *, 'c_8=',const8
         print *, 'c_9=',const9
         print *, 'c_10=',const10
         print *
      endif

      if(el.GT.elmax) then
         print *,'ERROR: Increase elmax in params.h to at least',el
         stop
      endif
c      if(NumOutLines+1.GT.NROWS) then
c         print *,'ERROR: Increase NROWS in params.h to at least',
c     $        NumOutLines+1
c         print *,'You may also have to change NROWS, or its'
c         print *,'equivalent, in your driver program.'
c         print *,'Current value of NROWS=',NROWS
c         stop
c      endif

      if(verbosity.ge.1) print *,
     &     'Entering MAKEMEASTAR w/ periastron parameter r_p/(R_1+R_2)='
     &     ,peri

* read in the input files for each parent star K:
      DO K=1,N
         if(verbosity.ge.2) WRITE(6,*)
         if(verbosity.ge.1) WRITE(6,*) 'Input: ',parentfile(K)
         
         OPEN(26,FILE=parentfile(K))
         
* I refers to rows in the input data file.  JJ refers to rows where the
* enclosed mass M is increasing.   We will throw away any rows where this does
* not occur.  (Some input files may have truncated the value for the mass at
* a small enough number of digits that two rows appear to have the same
* enclosed mass M.)
         JJ=0
         DO I=1,NROWS
            READ(26,*,END=30) Mp(I,K),Rp(I,K),Pp(I,K),
     &           Dp(I,K),(ELp(I,C,K), C=1,el)
            IF(Mp(I,K).GT.Mp(JJ,K) .OR. JJ.EQ.0) THEN
               JJ=JJ+1
               Mp(JJ,K)=Mp(I,K)
               Pp(JJ,K)=Pp(I,K)
               Dp(JJ,K)=Dp(I,K)
               DO C=1,el
                  ELp(JJ,C,K)=ELp(I,C,K)
               ENDDO
               Rp(JJ,K)=Rp(I,K)
            ENDIF
         ENDDO
            
 30      Jpmax(K)=JJ
         CLOSE(26)

      ENDDO

* Now we have to calculate A.

      DO K=1,N
         if(verbosity.ge.2) WRITE(6,*)

         alreadyfudged=.false.
         DO I=1,Jpmax(K)
            Aptry(K)=Pp(I,K)/Dp(I,K)**(5.d0/3.d0)

* We want to fake data for which the "entropy" A does not increase.  Therefore
* the else part of the IF statement fakes bad data.  In particular,
* the "entropy" is forced to increase ever so slightly.
            IF(Aptry(K).GT.Ap(I-1,K) .OR. I.EQ.1) THEN
               Ap(I,K)=Aptry(K)
            else
               Ap(I,K)=1.00001d0*Ap(I-1,K)
C               Ap(I,K)=1.001d0*Ap(I-1,K)
               if(.not. alreadyfudged) then
                  if(verbosity.ge.2) then
                     print *,
     &                 'Fudging A profile outside m/M_solar=',
     &                 Mp(I,K)/Msun,' in star',K
                     print *
                  endif
                  alreadyfudged=.true.
               endif
            endif
         ENDDO

         if(verbosity.ge.2) then
            print *, 'Information about star',K,':'
            WRITE(6,*) 'Jpmax(',K,')=',Jpmax(K)
            WRITE(6,*) 'Mass (in solar units)=',Mp(Jpmax(K),K)/Msun
            WRITE(6,*) 'Radius (in solar units)=',Rp(Jpmax(K),K)/Rsun
         endif

         CALL ENERGY(Mp(1,K),Pp(1,K),Dp(1,K),Rp(1,K),
     &        Jpmax(K),K)
         
      ENDDO

      if(Mp(Jpmax(2),2).gt.Mp(Jpmax(1),1))
     $     pause 'The more massive star is supposed to be first...'

c     First find mass loss for the headon collision case between these two
c     parent stars:
      periastron=0.d0
      CALL LOSEMASS

c Determine the intercept b_1 for the shock heating for the headon case
      INTlow=-0.9d0
      INThigh=0.9d0
c      call zbrak(DELNRG,INTlow,INThigh,3,xb1,xb2,nb)
C      print *, 'Back from zbrak: number of bracketing pairs was',nb
c      if(nb.ne.1 .and. verbosity.ge.2) then
c         print *
c         print *, 'The number of bracketing pairs was',nb
c         if(nb.eq.0) stop
c         print *, 'We are going to find the model with the most'
c         print *, 'shock heating.  (The models with less shock'
c         print *, 'heating most likely were not having their'
c         print *, 'energies calculated accurately, which you'
c         print *, 'can confirm by checking above to see if the'
c         print *, 'virial of the remnant was ever abnormally'
c         print *, 'large.)'
c      endif
c
c      NEWINT=ZBRENT3(DELNRG,xb1(nb),xb2(nb),1.d-4)

      NEWINT=ZBRENT3(DELNRG,INTlow,INThigh,1.d-4)
      if(verbosity.ge.1) print *,
     &     'The headon collision gave an intercept b_1=',NEWINT

      if(peri.ne.0.d0) then
         periastron=peri
         if(verbosity.ge.2) print *
         if(verbosity.ge.1)
     &        print *,'WE CAN NOW TREAT THE ACTUAL PERIASTRON CASE...'
         CALL LOSEMASS
         NEWINT=NEWINT-const4*periastron*
     &        LOG10(Mp(Jpmax(1),1)/Mp(Jpmax(2),2))
         if(verbosity.ge.1) then
            print *,'For this periastron separation, b_1=',NEWINT
         endif
      endif

      if(verbosity.ge.2) WRITE(6,*)
      if(verbosity.ge.2) WRITE(6,*) 'Starting final SHOCK'
      CALL SHOCK(NEWINT)
      if(verbosity.ge.2) then
         DO K=1,N
            print *,'central shocked A for star',K,' =',As(1,K)
            print *,'surface shocked A for star',K,' =',As(Jpmax(K),K)
            print *,'shocked A for star',K,' at last bound mass=',
     &           As(Pmax(K),K)
            print *,'mass lost from star',K,'=',Mp(Jpmax(K),K)
     $           -Mp(Pmax(K),K)
         ENDDO
         print *,'fraction of ejecta from star 2=',
     $        (Mp(Jpmax(2),2)-Mp(Pmax(2),2))/
     $        (Mp(Jpmax(1),1)-Mp(Pmax(1),1)
     $        +Mp(Jpmax(2),2)-Mp(Pmax(2),2))
      endif

      if(el.eq.0 .and. .not. studymassloss) then
         if(verbosity.ge.2) WRITE(6,*) 'SKIPPING THE MIXING'
      else
         DO K=1,N
            if(verbosity.ge.2) then
               WRITE(6,*)
               WRITE(6,*) 'Calculating mixing for star',K
            endif
            CALL MIX(K)
         ENDDO
      endif


      if(makeshockfiles) then
         do K=1,2
            WRITE(OUTFN,102) K
 102        FORMAT('shock',I1,'.sbe')
            if(verbosity.ge.2) print *,'WRITING SHOCK FILE...',OUTFN
            open(19,file=OUTFN)
            Do I=1,Jpmax(K)
               write(19,*) Mp(I,K),dlog10(As(I,K)-Ap(I,K)),
     $              dlog10(As(I,K)/Ap(I,K))
            enddo
            close(19)
            if(verbosity.ge.2) print *,'...DONE'
         enddo
      endif
      
* Pmax(K) comes from the LOSEMASS subroutine.

      if(verbosity.ge.2) then
         WRITE(6,*)
         WRITE(6,*) 'Starting final SORT'
      endif
      CALL SORT
      if(verbosity.ge.2) then
         WRITE(6,*) 'surface A for remnant=',Ar(Jrmax)
         WRITE(6,*) 'central A for remnant=',Ar(1)
         WRITE(6,*) 'row max for remnant (Jrmax)=',Jrmax
      endif
      
      if(verbosity.ge.2) then
         WRITE(6,*)
         WRITE(6,*) 'Starting final PROFILE'
      endif
      CALL PROFILE
      
      W=0.d0
      DO K=1,N
         W=TotE(K)+W
      ENDDO

      if(verbosity.ge.2) then      
         WRITE(6,*)
         WRITE(6,*) 'Total energy of parent stars is',W
      endif
      if(verbosity.ge.1) then
         WRITE(6,*) 'Total mass of remnant (in solar units) is',
     &        Mr(Jrmax)/Msun
         DO K=1,N
            print *, 'Radius of parent star ',K,' (in solar units)='
     &           ,Rp(Jpmax(K),K)/Rsun
            print *, 'Mass of parent star ',K,' (in solar units)='
     &           ,Mp(Jpmax(K),K)/Msun
         ENDDO
      endif
      Jtot=Mp(Jpmax(1),1)*Mp(Jpmax(2),2)*
     &     (2*G*periastron*(Rp(Jpmax(1),1)+Rp(Jpmax(2),2))/
     &     (Mp(Jpmax(1),1)+Mp(Jpmax(2),2))
     &     )**0.5d0
      if(verbosity.ge.2) print *,
     &     'Total angular momentum of parent stars is (cgs)',Jtot
      TotJrem=Jtot*(1.d0-const9*MLsfrac)
      if(verbosity.ge.2) then
         print *,'f_L * J_tot=',MLsfrac*Jtot
         print *,'Total angular momentum of remnant is (cgs)',TotJrem
         print *, 'J_remnant/M_remnant = ',TotJrem/Mr(Jrmax)
         print *,'Total system energy E_tot is (cgs)',TotE(1)+TotE(2)
         print *,'Total energy of remnant is (cgs)',TotErem
         print *,'f_L * E_tot=',MLsfrac*(TotE(1)+TotE(2))
      endif

      throwaway=0
      DO Jr=1,Jrmax
         if(P(Jr).lt.0.d0 .and. Jr.lt.Jrmax) then
            throwaway=throwaway+1
         else
            Mremnant(Jr-throwaway)=Mr(Jr)
            Aremnant(Jr-throwaway)=Ar(Jr)
            Premnant(Jr-throwaway)=dabs(P(Jr))
            Dremnant(Jr-throwaway)=D(Jr)
            Rremnant(Jr-throwaway)=R(Jr)
            do C=1,el
*     Note that the order of the arguments is different in ELremnant than it
*     is in Elr.
               Elremnant(C,Jr-throwaway)=ELr(Jr,C)
            enddo
         endif
      ENDDO

      if(verbosity.ge.2) then
         print *,'Jrmax=',Jrmax
         print *, 'throwing away',throwaway,' lines.'
      endif
      NumOutLines=Jrmax-throwaway

      Do Jr=1,NumOutLines
c jtryout will keep track of j in the outer layers, without yet including
c the contribution due to the k_3 term:
         jtryout(Jr)=(G*Mremnant(Jr)*Rremnant(Jr))**0.5d0*
     $        (Mremnant(Jr)/Mremnant(NumOutLines))**(1.d0/3.d0)

         cs=(5.d0/3.d0*Premnant(Jr)/Dremnant(Jr))**0.5d0
         jcs=cs*Rremnant(Jr)
c jtryin will keep track of j in the inner layers:
         jtryin(Jr)=const10*jcs*
     $        (Mremnant(Jr)/Mremnant(NumOutLines))**(1.d0/3.d0)
      enddo

c unscaledJtotout keeps track of the total angular momentum for the shells
c outside (and including) the shell in question, without the k3 contribution:
      unscaledJtotout(NumOutLines)=jtryout(NumOutLines)*0.5d0*
     $     (Mremnant(NumOutLines)-Mremnant(NumOutLines-1))
      Do Jr=NumOutLines-1,2,-1
         unscaledJtotout(Jr)=unscaledJtotout(Jr+1)+
     $        jtryout(Jr)*0.5d0*(Mremnant(Jr+1)-Mremnant(Jr-1))
      enddo
      unscaledJtotout(1)=unscaledJtotout(2)+
     $     jtryout(1)*0.5d0*(Mremnant(1)+Mremnant(2))
         
c Jtotin keeps track of the total angular momentum for the shells
c inside (and including) the shell in question:
      Jtotin=jtryin(1)*0.5d0*(Mremnant(1)+Mremnant(2))
      do Jr=2,NumOutLines
C get k_2 by matching slope of j...
         k2=(jtryin(Jr)-jtryin(Jr-1))/(jtryout(Jr)-jtryout(Jr-1))

C get k_3 by matching j itself
         k3=0.5d0*(
     $        jtryin(Jr-1)+jtryin(Jr)
     $        -k2*(jtryout(Jr-1)+jtryout(Jr))
     $        )

         scaledJtot=Jtotin+k2*unscaledJtotout(Jr)+
     $        k3*(
     $        Mremnant(NumOutLines)-0.5d0*(Mremnant(Jr-1)+Mremnant(Jr))
     $        )

c         print *, Jr, scaledJtot,TotJrem,
c     $        0.5d0*(Mremnant(Jr)+Mremnant(Jr-1))/Mremnant(NumOutLines)

         if ((scaledJtot-TotJrem)*diff .le. 0.d0 .and. Jr.gt.2) then
            if(dabs(scaledJtot-TotJrem).lt.dabs(diff)) then
               Jrtransition=Jr
            else
               Jrtransition=Jr-1
            endif
            if(verbosity.ge.2) then
               print *, 'Transition occurs near m/M_r=',
     $              0.5d0*
     $              (Mremnant(Jrtransition)+Mremnant(Jrtransition-1))
     $              /Mremnant(NumOutLines)
            endif

C tweak k2 so that get exactly the desired total angular momentum
            k2=(TotJrem-Jtotin-k3*(
     $        Mremnant(NumOutLines)-0.5d0*(Mremnant(Jr-1)+Mremnant(Jr))
     $        ))/unscaledJtotout(Jr)
            goto 234
         endif

C Figure out Jtotin for the next iteration....
         if(Jr.lt.NumOutLines) then
            Jtotin=Jtotin+0.5d0*jtryin(Jr)*
     $           (Mremnant(Jr+1)-Mremnant(Jr-1))
         else
            Jtotin=Jtotin+0.5d0*jtryin(Jr)*
     $           (Mremnant(Jr)-Mremnant(Jr-1))            
         endif

         diff=scaledJtot-TotJrem

      enddo

      if (verbosity.ge.2) then
         print *, 'Using only the form for the outer layer'
      endif
      Jrtransition=1
      k3=0.d0
      k2=TotJrem/unscaledJtotout(1)

 234  continue
      if(verbosity.ge.2) then
         print *,'k2=',k2,' k3=',k3
      endif

      Do Jr=1,Jrtransition-1
         jremnant(Jr)=jtryin(Jr)
      enddo
      Do Jr=Jrtransition,NumOutLines
         jremnant(Jr)=k2*jtryout(Jr)+k3
      enddo
      
      scaledJtot=jremnant(1)*0.5d0*(Mremnant(1)+Mremnant(2))
      do Jr=2, NumOutLines-1
         scaledJtot=scaledJtot+jremnant(Jr)*0.5d0*
     $        (Mremnant(Jr+1)-Mremnant(Jr-1))
      enddo
      scaledJtot=scaledJtot+jremnant(NumOutLines)*0.5d0*
     $     (Mremnant(NumOutLines)-Mremnant(NumOutLines-1))
      if(verbosity.ge.2) then
         print *,'Total J=',scaledJtot,'=',TotJrem
         print *, 'DONE!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!'
      endif
      END
      
*************************************************************
*************************************************************
*************************************************************
*************************************************************
*************************************************************
*************************************************************
*************************************************************

*************************************************************
* ZBRENT minimizes the radius                               *
*************************************************************
      FUNCTION zbrent(func,x1,x2,tol)
      INTEGER ITMAX
      DOUBLE PRECISION zbrent,tol,x1,x2,func,EPS
      EXTERNAL func
      PARAMETER (ITMAX=1000,EPS=3.d-8)
      INTEGER iter
      DOUBLE PRECISION a,b,c,d,e,fa,fb,fc,p,q,r,s,tol1,xm

      a=x1
      b=x2
      fa=func(a)
      fb=func(b)
      if((fa.gt.0.d0.and.fb.gt.0.d0).or.
     &     (fa.lt.0.d0.and.fb.lt.0.d0))then
         print *
         print *,'You must be pushing the limits of this code.'
         print *,'Try letting Rup be even larger [increase the'
         print *,'size of the term being added to R(Jr-1)]'
         print *,'and see if that helps you get a model...'
         print *,'Also consider emailing lombardi@vassar.edu'
         pause 'root must be bracketed for zbrent'
      endif
      c=b
      fc=fb
      do 11 iter=1,ITMAX
        if((fb.gt.0.d0.and.fc.gt.0.d0).or.
     &        (fb.lt.0.d0.and.fc.lt.0.d0))then
          c=a
          fc=fa
          d=b-a
          e=d
        endif
        if(abs(fc).lt.abs(fb)) then
          a=b
          b=c
          c=a
          fa=fb
          fb=fc
          fc=fa
        endif
        tol1=2.d0*EPS*abs(b)+0.5d0*tol
        xm=.5d0*(c-b)
        if(abs(xm).le.tol1 .or. fb.eq.0.d0)then
          zbrent=b
          return
        endif
        if(abs(e).ge.tol1 .and. abs(fa).gt.abs(fb)) then
          s=fb/fa
          if(a.eq.c) then
            p=2.d0*xm*s
            q=1.d0-s
          else
            q=fa/fc
            r=fb/fc
            p=s*(2.d0*xm*q*(q-r)-(b-a)*(r-1.d0))
            q=(q-1.d0)*(r-1.d0)*(s-1.d0)
          endif
          if(p.gt.0.d0) q=-q
          p=abs(p)
          if(2.d0*p .lt. min(3.d0*xm*q-abs(tol1*q),abs(e*q))) then
            e=d
            d=p/q
          else
            d=xm
            e=d
          endif
        else
          d=xm
          e=d
        endif
        a=b
        fa=fb
        if(abs(d) .gt. tol1) then
          b=b+d
        else
          b=b+sign(tol1,xm)
        endif
        fb=func(b)
11    continue
      pause 'zbrent exceeding maximum iterations'
      zbrent=b
      return
      END

*************************************************************
*ZBRENT2 minimizes the pressure                             *
*************************************************************
      FUNCTION zbrent2(func,x1,x2,tol)
      INTEGER ITMAX
      DOUBLE PRECISION zbrent2,tol,x1,x2,func,EPS
      EXTERNAL func
      PARAMETER (ITMAX=100,EPS=3.d-8)
      INTEGER iter
      DOUBLE PRECISION a,b,c,d,e,fa,fb,fc,p,q,r,s,tol1,xm

      a=x1
      b=x2
      fa=func(a)
c      print *,'A:',a,fa
      fb=func(b)
c      print *,'B:',b,fb
      if((fa.gt.0.d0.and.fb.gt.0.d0).or.
     &     (fa.lt.0.d0.and.fb.lt.0.d0))then
         print *
         print *,'You must be pushing the limits of this code.'
         print *,'Try expanding the range of Pclow and Pchigh'
         print *,'and see if that helps you get a model...'
         print *,'Also consider emailing lombardi@vassar.edu'
         pause 'root must be bracketed for ... zbrent2'
      endif
      c=b
      fc=fb
      do 11 iter=1,ITMAX
        if((fb.gt.0.d0.and.fc.gt.0.d0).or.
     &        (fb.lt.0.d0.and.fc.lt.0.d0))then
          c=a
          fc=fa
          d=b-a
          e=d
        endif
        if(abs(fc).lt.abs(fb)) then
          a=b
          b=c
          c=a
          fa=fb
          fb=fc
          fc=fa
        endif
        tol1=2.d0*EPS*abs(b)+0.5d0*tol
        xm=.5d0*(c-b)
        if(abs(xm).le.tol1 .or. fb.eq.0.d0)then
          zbrent2=b
          return
        endif
        if(abs(e).ge.tol1 .and. abs(fa).gt.abs(fb)) then
          s=fb/fa
          if(a.eq.c) then
            p=2.d0*xm*s
            q=1.d0-s
          else
            q=fa/fc
            r=fb/fc
            p=s*(2.d0*xm*q*(q-r)-(b-a)*(r-1.d0))
            q=(q-1.d0)*(r-1.d0)*(s-1.d0)
          endif
          if(p.gt.0.d0) q=-q
          p=abs(p)
          if(2.d0*p .lt. min(3.d0*xm*q-abs(tol1*q),abs(e*q))) then
            e=d
            d=p/q
          else
            d=xm
            e=d
          endif
        else
          d=xm
          e=d
        endif
        a=b
        fa=fb
        if(abs(d) .gt. tol1) then
          b=b+d
        else
          b=b+sign(tol1,xm)
        endif
        fb=func(b)
11    continue
      pause 'zbrent2 exceeding maximum iterations'
      zbrent2=b
      return
      END

*************************************************************
* ZBRENT3 used to minimize delta Energy                     *
*************************************************************
      FUNCTION zbrent3(func,x1,x2,tol)
      INTEGER ITMAX
      DOUBLE PRECISION zbrent3,tol,x1,x2,func,EPS
      EXTERNAL func
      PARAMETER (ITMAX=100,EPS=3.d-8)
      INTEGER iter
      DOUBLE PRECISION a,b,c,d,e,fa,fb,fc,p,q,r,s,tol1,xm
 
      a=x1
      b=x2
      fa=func(a)
      fb=func(b)
      if((fa.gt.0.d0.and.fb.gt.0.d0).or.
     &     (fa.lt.0.d0.and.fb.lt.0.d0))then
         print *
         print *,'You must be pushing the limits of this code.'
         print *,'Try expanding the range of INTlow and INThigh'
         print *,'and see if that helps you get a model...'
         print *,'Also consider emailing lombardi@vassar.edu'
         pause 'root must be bracketed for zbrent3'
      endif
      c=b
      fc=fb
      do 11 iter=1,ITMAX
        if((fb.gt.0.d0.and.fc.gt.0.d0).or.
     &        (fb.lt.0.d0.and.fc.lt.0.d0))then
          c=a
          fc=fa
          d=b-a
          e=d
        endif
        if(abs(fc).lt.abs(fb)) then
          a=b
          b=c
          c=a
          fa=fb
          fb=fc
          fc=fa
        endif
        tol1=2.d0*EPS*abs(b)+0.5d0*tol
        xm=.5d0*(c-b)
        if(abs(xm).le.tol1 .or. fb.eq.0.d0)then
          zbrent3=b
          return
        endif
        if(abs(e).ge.tol1 .and. abs(fa).gt.abs(fb)) then
          s=fb/fa
          if(a.eq.c) then
            p=2.d0*xm*s
            q=1.d0-s
          else
            q=fa/fc
            r=fb/fc
            p=s*(2.d0*xm*q*(q-r)-(b-a)*(r-1.d0))
            q=(q-1.d0)*(r-1.d0)*(s-1.d0)
          endif
          if(p.gt.0.d0) q=-q
          p=abs(p)
          if(2.d0*p .lt. min(3.d0*xm*q-abs(tol1*q),abs(e*q))) then
            e=d
            d=p/q
          else
            d=xm
            e=d
          endif
        else
          d=xm
          e=d
        endif
        a=b
        fa=fb
        if(abs(d) .gt. tol1) then
          b=b+d
        else
          b=b+sign(tol1,xm)
        endif
        fb=func(b)
 11         continue
      pause 'zbrent3 exceeding maximum iterations'
      zbrent3=b
      return
      END
 
      FUNCTION DELNRG(INTERCEPT)

      IMPLICIT NONE
      INCLUDE 'params.h'
      INTEGER K,verbosity
      DOUBLE PRECISION W,TotE(N),TotErem,INTERCEPT,DELNRG,MLsfrac
      COMMON/NRG/TotE,TotErem
      COMMON/MASSLOSS/MLsfrac
      COMMON/verbiage/verbosity

      if(verbosity.ge.2) then
         WRITE(6,*)
         WRITE(6,*) '***minimizing to find intercept***'
      endif

      CALL SHOCK(INTERCEPT)
      CALL SORT
      CALL PROFILE

      W=0.d0
      DO K=1,N
         W=TotE(K)+W
      ENDDO

      DELNRG=TotErem/W-1.d0-const7*MLsfrac
      if(verbosity.ge.2)
     & print *,'delta energy=',DELNRG,'(we want this to become small)'

      RETURN
      END
      SUBROUTINE ENERGY(M,P,D,R,Jmax,STAR)

*************************************************************
* This routine will calculate the total energy of a star.   *
*************************************************************

      IMPLICIT NONE
      INCLUDE 'params.h'
      INTEGER J,Jmax,STAR,T,verbosity
      DOUBLE PRECISION P(NROWS),D(NROWS),M(NROWS),R(NROWS),
     &     Ei,Eg,delM,TotE(N),TotErem
      COMMON/NRG/TotE,TotErem
      COMMON/verbiage/verbosity

* A star's total energy consists of its gravitational energy, Eg,
* and its internal energy, Ei.  These are calculated for the star's
* innermost point and then numerically integrated outward.

      Ei=3.d0/2.d0*P(1)/D(1)*M(1)
      Eg=-G*(4.d0*D(1)*pi)**2.d0/15.d0*R(1)**5.d0

      T=2
      IF(R(1).EQ.0.d0) THEN
         Ei=Ei+3.d0/2.d0*P(2)/D(2)*M(2)
         Eg=Eg-G*(4.d0*D(2)*pi)**2.d0/15.d0*R(2)**5.d0
         T=3
      ENDIF

      DO J=T,Jmax
         delM=M(J)-M(J-1)
         Eg=Eg-G*delM*(M(J)/R(J)+M(J-1)/R(J-1))*0.5d0
         Ei=Ei+3.d0/4.d0*(P(J)/D(J)+P(J-1)/D(J-1))*delM
      ENDDO

      IF(STAR.GT.N) THEN
         if(verbosity.ge.2)
     &        WRITE(6,*) 'Total energy for remnant =',Eg+Ei
         TotErem=Eg+Ei
      ELSE
         if(verbosity.ge.2)
     &        WRITE(6,*) 'Total energy for star',STAR,' =',Eg+Ei
      ENDIF

* If all goes well, the Virial Theorem should hold and 2Ei+Eg=0.

      if(verbosity.ge.2) WRITE(6,*) '2Ei+Eg=',2.d0*Ei+Eg
      
      TotE(STAR)=Eg+Ei

      if(dabs((2.d0*Ei+Eg)/TotE(STAR)).gt.1d-2) then
         print *
         print *, 'WARNING ... WARNING ... WARNING'
         print *, 'virial/(total energy)=',(2.d0*Ei+Eg)/TotE(STAR)
         print *, 'which seems to be quite far away from 0.'
         print *, 'This ratio would be zero for a star in'
         print *, 'hydrostatic equilibrium.'
         print *, 'Internal energy=',Ei
         print *, 'Gravitational potential energy=',Eg
         if(STAR.GT.N) then
            print *, 'The remnant seems to be far from equilibrium,'
            print *, 'which is OK as long as this is not the last call'
            print *, 'to PROFILE....  If it is the last call,'
            print *, 'you should probably request larger arrays'
            print *, 'for your remnant profiles.  If this does not'
            print *, 'help, consider emailing lombardi@vassar.edu'
         else
            print *, 'Parent star',STAR,' seems to be far from'
            print *, 'equilibrium.  Are you sure you the input'
            print *, 'data file for this star has a reasonably'
            print *, 'large number of rows in it?'
c            pause
         endif
      endif
      
      END
      SUBROUTINE LOSEMASS

******************************************************************
* This routine will estimate the mass loss for each parent star. *
* Any data beyond what is "lost" will be ignored.                *
******************************************************************

      IMPLICIT NONE
      INCLUDE 'params.h'
      INTEGER Jpmax(N),Pmax(N),I50(N),verbosity,I86(N),I95(N),K
      DOUBLE PRECISION Mp(NROWS,N),Rp(NROWS,N),
     &     ELp(NROWS,elmax,N),
     &     MLsfrac,Dp(NROWS,N),Ap(NROWS,N),MLoseTotal,
     &     periastron,As(NROWS,N),ELm(NROWS,elmax,N),
     &     Rp50(N),Rp86(N),Rp95(N)
      COMMON/NEWINFO/ELp,Mp,Rp,Pmax,ELm
      COMMON/NEWENT/Jpmax,Ap,Dp,As
      COMMON/MASSLOSS/MLsfrac
      COMMON/PERI/periastron
      COMMON/verbiage/verbosity
      COMMON/index/ I50
      SAVE Rp86, Rp95

      if(verbosity.ge.2) then
         WRITE(6,*)
         WRITE(6,*) 'Entering LOSEMASS FOR PERIASTRON=',periastron
         if(periastron.eq.0.d0)
     &        print *,'EVEN IF YOU DID NOT REQUEST A HEADON COLLISION',
     &        'WE STILL HAVE TO WORK ON THE HEADON CASE FOR A WHILE.'
      endif

      IF(N.NE.2) THEN
         print *, 'WARNING: MASS LOSS DOES NOT WORK UNLESS THERE ARE',
     &            ' TWO STARS'
         STOP
      ENDIF

* There should be no need to find the 50% radius if periastron is non-zero,
* because that should have already been done when treating the periastron=0
* case:
      if(periastron.eq.0.d0) then
         call geti50(I50,I86,I95)
         DO K=1,N
            Rp50(K)=((Mp(I50(K),K)/Mp(Jpmax(K),K)-.5d0)*Rp(I50(K)-1,K)+
     $           (.5d0-Mp(I50(K)-1,K)/Mp(Jpmax(K),K))*Rp(I50(K),K))/
     $           (Mp(I50(K),K)-Mp(I50(K)-1,K))*Mp(Jpmax(K),K)
            Rp86(K)=((Mp(I86(K),K)/Mp(Jpmax(K),K)-.86d0)*Rp(I86(K)-1,K)+
     $           (.86d0-Mp(I86(K)-1,K)/Mp(Jpmax(K),K))*Rp(I86(K),K))/
     $           (Mp(I86(K),K)-Mp(I86(K)-1,K))*Mp(Jpmax(K),K)
            Rp95(K)=((Mp(I95(K),K)/Mp(Jpmax(K),K)-.95d0)*Rp(I95(K)-1,K)+
     $           (.95d0-Mp(I95(K)-1,K)/Mp(Jpmax(K),K))*Rp(I95(K),K))/
     $           (Mp(I95(K),K)-Mp(I95(K)-1,K))*Mp(Jpmax(K),K)
        ENDDO
         if(verbosity.ge.2) then
            print *,'R_{0.5} are',Rp50(1)/Rsun,' and',
     $           Rp50(2)/Rsun,' solar radii *** using these numbers'
            print *,'R_{0.86} are',Rp86(1)/Rsun,' and',
     $           Rp86(2)/Rsun,' solar radii'
            print *,'R_{0.95} are',Rp95(1)/Rsun,' and',
     $           Rp95(2)/Rsun,' solar radii *** using these numbers'
         endif
      endif

* Now we calculate the mass lost.  It depends on the 
* reduced mass, the radius of the star in question, and the radii at
* a mass fractions of 50% and 95% in both stars.  The coefficient
* const1 is determined 
* by calculating this information for a number of cases and averaging.

      MLoseTotal=
     &        const1*Mp(Jpmax(1),1)*Mp(Jpmax(2),2)*
     &        (Rp86(1)+Rp86(2))/
     &        ((Mp(Jpmax(1),1)+Mp(Jpmax(2),2))*
     &        (Rp(I50(1),1)+Rp(I50(2),2) +
     &         const2*periastron*(Rp(Jpmax(1),1)+Rp(Jpmax(2),2)) ))
c      MLoseTotal=
c     &        const1*Mp(Jpmax(1),1)*Mp(Jpmax(2),2)*
c     &        (Rp95(1)+Rp95(2))/
c     &        ((Mp(Jpmax(1),1)+Mp(Jpmax(2),2))*
c     &        (Rp(I50(1),1)+Rp(I50(2),2) +
c     &         const2*periastron*(Rp(Jpmax(1),1)+Rp(Jpmax(2),2)) ))
      MLsfrac=MLoseTotal/(Mp(Jpmax(1),1)+Mp(Jpmax(2),2))

      if(verbosity.ge.1) then
         print *,
     &'Mass loss fraction =',MLsfrac,' for periastron=',periastron,
     &', corresponding to a remnant mass of',(1.d0-MLsfrac)*
     &        (Mp(Jpmax(1),1)+Mp(Jpmax(2),2))/Msun,' Msun'
c         print *,
c     &', corresponding to a table mass of',(1.d0-MLsfrac)*
c     &        ( NINT(100.d0*Mp(Jpmax(1),1)/Msun)/100.d0
c     $         +NINT(100.d0*Mp(Jpmax(2),2)/Msun)/100.d0 ),' Msun'
      endif
      RETURN
      END

******************************************************************
******************************************************************
******************************************************************
      subroutine geti50(I50,I86,I95)

******************************************************************
* This routine finds the locations in the parent inside of which *
* 50%, 86% and 95% of the total mass is enclosed                 *
******************************************************************
      
      implicit none
      INCLUDE 'params.h'
      INTEGER I,K,Jpmax(N),Pmax(N),I50(N),I86(N),I95(N)
      DOUBLE PRECISION Mp(NROWS,N),Rp(NROWS,N),
     &     ELp(NROWS,elmax,N),
     &     Dp(NROWS,N),Ap(NROWS,N),
     &     As(NROWS,N),ELm(NROWS,elmax,N)
      COMMON/NEWINFO/ELp,Mp,Rp,Pmax,ELm
      COMMON/NEWENT/Jpmax,Ap,Dp,As

      DO K=1,N
         DO I=1,NROWS
            IF(Mp(I,K).GE.50.d-2*Mp(Jpmax(K),K)) GOTO 47
         ENDDO
 47      I50(K)=I
         DO I=I50(K)+1,NROWS
            IF(Mp(I,K).GE.86.d-2*Mp(Jpmax(K),K)) GOTO 48
         ENDDO
 48      I86(K)=I
         DO I=I86(K)+1,NROWS
            IF(Mp(I,K).GE.95.d-2*Mp(Jpmax(K),K)) GOTO 49
         ENDDO
 49      I95(K)=I
      ENDDO

      END

      SUBROUTINE MIX(K)

*****************************************************************
* This routine will model the hydrodynamic mixing of the        *
* chemical compositions                                         *
* in the parent stars, after shock heating has occurred and     *
* before mass loss takes place.                                 *
*****************************************************************

      IMPLICIT NONE
      INCLUDE 'params.h'
      INTEGER C,K,L,I,J,Jpmax(N),Max,Pmax(N),verbosity
c     integer halfway
      DOUBLE PRECISION ELp(NROWS,elmax,N),As(NROWS,N),Mp(NROWS,N),
     &     DENOM(NROWS),CONTRIB,dM(NROWS),alpha,
     &     F(NROWS,NROWS),dlogAdM(NROWS),ELm(NROWS,elmax,N),ELmtot,
     &     ELptot,Dp(NROWS,N),Ap(NROWS,N),Rp(NROWS,N),dlogAdMavg
      COMMON/NEWENT/Jpmax,Ap,Dp,As
      COMMON/NEWINFO/ELp,Mp,Rp,Pmax,ELm
      COMMON/verbiage/verbosity
      common/numel/el
      double precision FBOUND(NROWS)
      character*16 OUTFN

      Max=Jpmax(K)

      DO I=2,Max-1
         dM(I)=0.5d0*(Mp(I+1,K)-Mp(I-1,K))
      ENDDO

      dM(1)=0.5d0*(Mp(2,K)+Mp(1,K))
      dM(Max)=0.5d0*(Mp(Max,K)-Mp(Max-1,K))

      dlogAdMavg=dlog(As(Pmax(K),K))-dlog(As(1,K))

      do I=1,Max
         FBOUND(I)=0.d0
      enddo

      alpha=-const8*dlogAdMavg**2.d0

      if(verbosity.ge.2) then
         print *,'Mp(Max,K)=',Mp(Max,K)
         print *,'dlogAdMavg=',dlogAdMavg,', alpha from paper=',-alpha
c Note that the alpha in the paper has the opposite sign from the alpha in
c this code
      endif

      DO I=1,Max
         DENOM(I)=0.d0
         DO J=1,Max
            F(J,I)=exp(alpha*((Mp(J,K)-Mp(I,K))/Mp(Max,K))**2.d0)
     &            +exp(alpha*((Mp(J,K)+Mp(I,K))/Mp(Max,K))**2.d0)
     &            +exp(alpha*((2.d0*Mp(Max,K)-Mp(J,K)
     &                                 -Mp(I,K))/Mp(Max,K))**2.d0)
            DENOM(I)=DENOM(I)+dM(J)*F(J,I)
         ENDDO
      ENDDO

      DO I=1,Max
         DENOM(I)=dM(I)/DENOM(I)
      ENDDO


      if(studymassloss) then
         WRITE(OUTFN,101) K
 101     FORMAT('fbound',I1,'.sbe')
         open(19,file=OUTFN)
         DO I=1,Max
            DO J=1,Max
C     F(J,I)*DENOM(J)*dM(I) is the mass that went from shell J to shell I
               IF(I.LE.Pmax(K))
     $              FBOUND(J)=FBOUND(J)+F(J,I)*DENOM(J)*dM(I)
            ENDDO
         ENDDO
         
         DO I=1,Max
            FBOUND(I)=FBOUND(I)/dM(I)
            write(19,*) Mp(I,K)/Msun,FBOUND(I)
         enddo
         close(19)
      endif

      DO C=1,el
         ELptot=0.d0
         ELmtot=0.d0
         DO L=1,Max
            CONTRIB=0.d0
            DO I=1,Max
               CONTRIB=CONTRIB+ELp(I,C,K)*F(I,L)*DENOM(I)
C Elp(I,C,K)*F(I,L)*DENOM(I)*dM(L) is the amount of mass of species C that
C went from shell I to shell L in star K
            ENDDO
            ELm(L,C,K)=CONTRIB
            ELptot=ELptot+ELp(L,C,K)*dM(L)
            ELmtot=ELmtot+ELm(L,C,K)*dM(L)
         ENDDO
         if(verbosity.ge.2) WRITE(6,*) 'Element:',C

         IF((ELptot-ELmtot)/ELptot.GT.1.d-6) THEN
            WRITE(6,*) 'WARNING!!  Mass may NOT be conserved!'
            WRITE(6,*) 'ELptot=',ELptot,' ELmtot=',ELmtot
         ENDIF

      ENDDO

      RETURN
      END

      SUBROUTINE PROFILE

********************************************************************
* Given as input the remnant file made by SORT with M, A, chemical *
* data, this subroutine will find values for the remnant's         *
* pressure,  density, and radius.                                  *
********************************************************************

* All units are cgs.

* Define variables: ZBRENT2 is a slight modification of the root-finding
* function ZBRENT from Numerical Recipes.
* Pclow & Pchigh are lower and upper limits for the guess of the central
* pressure Pcntr

      IMPLICIT NONE
      INCLUDE 'params.h'
      INTEGER Jr,Jrmax,STAR,NP,verbosity
      DOUBLE PRECISION Pcntr,Pclow,Pchigh,Psurf
      DOUBLE PRECISION Mr(NROWS),Ar(NROWS),P(NROWS),
     &     D(NROWS),R(NROWS),ELr(NROWS,elmax)
      COMMON/REMNANT/Mr,Ar,ELr,Jrmax,Jr,NP
      COMMON/VARIABLES/P,D,R
      COMMON/verbiage/verbosity
      DOUBLE PRECISION ZBRENT2,PRESSURE
      EXTERNAL PRESSURE

* Define the limits for ZBRENT2:
* These limits would have to be adjusted if you are creating remnants
* with either exceedingly low or exceedingly high central pressures...
      Pclow=0.0000000000001d0*G*Msun**2.d0/(Rsun**4.d0)
      Pchigh=3000.d0*G*Msun**2.d0/(Rsun**4.d0)

      Pcntr=ZBRENT2(PRESSURE,Pclow,Pchigh,1.d-4)
      if(verbosity.ge.2) WRITE(6,*) 'Central pressure=',Pcntr
   
*** DO NOT REMOVE THE FOLLOWING ASSIGNMENT STATEMENT - IT IS NEEDED!!***
*** ONE FINAL CALL TO PRESSURE IS NEEDED TO GET CORRECT REMNANT PROFILES!!***
      Psurf=PRESSURE(Pcntr)

      if(verbosity.ge.2) WRITE(6,*) 'Surface pressure=',Psurf
c      IF(Psurf.LT.0.d0) THEN
c         P(Jrmax)=0.d0
c         if(verbosity.ge.2) WRITE(6,*) 'Surface pressure set to 0'
c      ENDIF

      Jr=1
      STAR=N+1
      CALL ENERGY(Mr(Jr),P(Jr),D(Jr),R(Jr),Jrmax,STAR)

      END

**************************************************************
      FUNCTION PRESSURE(Pctry)

      IMPLICIT NONE
      INCLUDE 'params.h'
      INTEGER Jr,Jrmax,T,NP
      DOUBLE PRECISION dM,Pctry,Rup
      DOUBLE PRECISION Mr(NROWS),Ar(NROWS),P(NROWS),D(NROWS),
     &     R(NROWS),ELr(NROWS,elmax)
      COMMON/REMNANT/Mr,Ar,ELr,Jrmax,Jr,NP
      COMMON/VARIABLES/P,D,R
      DOUBLE PRECISION PRESSURE,ZBRENT,RADIUS
      EXTERNAL RADIUS

      T=2

      P(1)=Pctry
      D(1)=(dabs(Pctry)/Ar(1))**(3.d0/5.d0)
      R(1)=(3.d0*Mr(1)/(4.d0*pi*D(1)))**(1.d0/3.d0)
      
      IF(R(1).EQ.0.d0) THEN
         dM=Mr(2)-Mr(1)
         R(2)=(3.d0*dM/(4.d0*pi*D(1)))**(1.d0/3.d0)
         P(2)=Pctry-2.d0*pi/3.d0*G*R(2)**2.d0*D(1)**2.d0
         D(2)=(dabs(P(2))/Ar(2))**(3.d0/5.d0)
         T=3
      ENDIF

      DO Jr=T,Jrmax
         dM=Mr(Jr)-Mr(Jr-1)
         Rup=R(Jr-1)+10.d0*dM/(4.d0*pi*(R(Jr-1)**2.d0)*
     &        dabs(D(Jr-1)))
         R(Jr)=ZBRENT(RADIUS,R(Jr-1),Rup,1.d-4)
         P(Jr)=P(Jr-1)-G/(8.d0*pi)*(Mr(Jr-1)/(R(Jr-1)**4.d0)+
     &        Mr(Jr)/(R(Jr)**4.d0))*dM
         D(Jr)=(dabs(P(Jr))/Ar(Jr))**(3.d0/5.d0)
      ENDDO

      PRESSURE=P(Jrmax)

      RETURN
      END


*****************************************************************
      FUNCTION RADIUS(RJr)

      IMPLICIT NONE
      INCLUDE 'params.h'
      INTEGER Jr,Jrmax,NP
      DOUBLE PRECISION Mr(NROWS),Ar(NROWS),P(NROWS),R(NROWS)
      DOUBLE PRECISION PJr,RJr,RADIUS,ELr(NROWS,elmax),D(NROWS)
      COMMON/REMNANT/Mr,Ar,ELr,Jrmax,Jr,NP
      COMMON/VARIABLES/P,D,R

      PJr=P(Jr-1)-G/(8.d0*pi)*(Mr(Jr-1)/(R(Jr-1)**4.d0)+
     &     Mr(Jr)/(RJr**4.d0))*(Mr(Jr)-Mr(Jr-1))
      RADIUS=-RJr+R(Jr-1)+(Mr(Jr)-Mr(Jr-1))/(8.d0*pi)*
     &     ((Ar(Jr-1)/P(Jr-1))**(3.d0/5.d0)/
     &     (R(Jr-1)**2.d0)+(Ar(Jr)/PJr)**(3.d0/5.d0)/(RJr**2.d0))

      RETURN
      END






      SUBROUTINE SHOCK(INTERCEPT)

*********************************************************************
* This routine will take the parent star entropy profiles and shock *
* them, creating a new entropy profile for SORT to accept and use   *
* to calculate the remnant's entropy.                               *
*********************************************************************

      IMPLICIT NONE
      INCLUDE 'params.h'

* Mto= turn-off mass in solar units
* Rto= turn-off radius in solar units
* (The use of Mto and Rto is simply because of the chosen units for the
* intercept.)
      DOUBLE PRECISION Mto,Rto
      PARAMETER(Mto=0.8d0*Msun, Rto=0.955d0*Rsun)

      INTEGER Jpmax(N),I,Imax,K,Pmax(N),I1,I2,verbosity
      DOUBLE PRECISION Ap(NROWS,N),As(NROWS,N),Dp(NROWS,N),INTERCEPT,
     &     Mp(NROWS,N),Rp(NROWS,N),ELp(NROWS,elmax,N),INTERCEPT2,slope,
     &     MLsfrac,MLoseTotal,massoutsideofI1,massoutsideofI2,
     &     periastron,ELm(NROWS,elmax,N)
      COMMON/NEWENT/Jpmax,Ap,Dp,As
      COMMON/NEWINFO/ELp,Mp,Rp,Pmax,ELm
      COMMON/MASSLOSS/MLsfrac
      COMMON/PERI/periastron
      COMMON/verbiage/verbosity
      double precision RHS
      character*16 OUTFN

* The equation for the shocked entropy, As, comes from a plot of
* Log(A-Ainit) vs. Log(Arho^5/3).  The value INTERCEPT is the y-intercept
* of the linear function fitted to the plot of the data.  The variable
* "const3" is the slope of that same function.

      DO K=1,N
         Imax=Jpmax(K)
         IF(K.EQ.1) THEN
            DO I=1,Imax
               RHS=INTERCEPT + dlog10(G*Mto**(1.d0/3.d0)*Rto)
     &              +const3*
     $              dlog10(Rto**4/Mto**2/G*Ap(I,K)*Dp(I,K)**(5.d0/3.d0))
               As(I,K)=Ap(I,K)+10.d0**RHS
c               As(I,K)=Ap(I,K)+10.d0**INTERCEPT*
c     &          G*Mto**(1.d0/3.d0)*Rto*
c     &          (Rto**4/Mto**2/G*Ap(I,K)*Dp(I,K)**(5.d0/3.d0))**const3
            ENDDO
         ELSE
            INTERCEPT2=INTERCEPT+((const4+const5)*periastron-const6)*
     &           LOG10(Mp(Jpmax(1),1)/Mp(Jpmax(K),K))
            DO I=1,Imax
               RHS=INTERCEPT2 + dlog10(G*Mto**(1.d0/3.d0)*Rto)
     &              +const3*
     $              dlog10(Rto**4/Mto**2/G*Ap(I,K)*Dp(I,K)**(5.d0/3.d0))
c               As(I,K)=Ap(I,K)+10.d0**INTERCEPT2*
c     &          G*Mto**(1.d0/3.d0)*Rto*
c     &          (Rto**4/Mto**2/G*Ap(I,K)*Dp(I,K)**(5.d0/3.d0))**const3
               As(I,K)=Ap(I,K)+10.d0**RHS
            ENDDO
            if(verbosity.ge.2) then
               print *, 'Intercept for star 2=',INTERCEPT2
               print *, 'Intercept for star 1=',INTERCEPT
            endif
         ENDIF
      ENDDO

      MLoseTotal=MLsfrac*(Mp(Jpmax(1),1)+Mp(Jpmax(2),2))
      I1=Jpmax(1)
      massoutsideofI1=0.d0
      massoutsideofI2=0.d0
      Do while (massoutsideofI1+massoutsideofI2 .lt. MLoseTotal)
         I1=I1-1
         massoutsideofI1=massoutsideofI1 + Mp(I1+1,1) - Mp(I1,1)

         I2=Jpmax(2)
         massoutsideofI2=0.d0
         do while(As(I2,2).gt.As(I1,1))
           I2=I2-1
           massoutsideofI2=massoutsideofI2 + Mp(I2+1,2) - Mp(I2,2)
         enddo
      enddo

      Pmax(1)=I1
      Pmax(2)=I2

      if(verbosity.ge.2) then
         print *,'Pmax(1)=',Pmax(1),' Pmax(2)=',Pmax(2)
         print *,'actual mass loss fraction=',
     &        (massoutsideofI1+massoutsideofI2)/
     &        (Mp(Jpmax(1),1)+Mp(Jpmax(2),2)),
     &        ' for r_p=',periastron
      endif

      RETURN
      END

      
      SUBROUTINE SORT

******************************************************************
* This subroutine will take the parent star data                 *
* of M, A and chemical abundances.  It will create similar arrays*
* for the remnant, sorted by increasing A.  In order             *
* to keep the remnant profile smooth, we'll account for the      *
* profile derivatives.                                           *
******************************************************************

* Define the variables:

* M is the mass enclosed in a star, A is the entropic variable at
* M, and EL is the chemical abundance at M.  Ji is the Jith row in 
* the data file for a star.

      IMPLICIT NONE
      INCLUDE 'params.h'
      INTEGER Jr,Jp(N),Jrmax,K,C,Pmax(N),Jpmax(N),NP
      DOUBLE PRECISION Mp(NROWS,N),ELp(NROWS,elmax,N),As(NROWS,N)
      DOUBLE PRECISION Mr(NROWS),Ar(NROWS),ELr(NROWS,elmax),Rp(NROWS,N)
      DOUBLE PRECISION dAr,dAsdMp(N),dArdMr,dArp(N),Mtmp,dAdMtmp,
     &     Armax,MofAr(N),Chemtmp(elmax),dArtmp,Chem(elmax,N),
     &     ELm(NROWS,elmax,N),
     &     Dp(NROWS,N),Ap(NROWS,N)
      COMMON/NEWINFO/ELp,Mp,Rp,Pmax,ELm
      COMMON/NEWENT/Jpmax,Ap,Dp,As
      COMMON/REMNANT/Mr,Ar,ELr,Jrmax,Jr,NP
      LOGICAL NOTDONE
      DOUBLE PRECISION dlogAr
      common/numel/el

* The maximum entropy in the remnant should be the highest in any of
* the parents:

      Armax=0.d0
      DO K=1,N
         Armax=max(Armax,As(Pmax(K),K))
      ENDDO

c      print *,'Armax=',Armax,' Pmax(1)=',Pmax(1),' Pmax(2)=',Pmax(2)

* Initialize the rows:

      DO K=1,N
         Jp(K)=1
      ENDDO
      Jr=1

* Initialize the entropy - the first value of Ar (at the lowest Mr)
* will be the lowest entropy in any of the parent stars.

      Ar(1)=1.d30
      DO K=1,N
         Ar(1)=min(Ar(1),As(1,K))
      ENDDO

      dlogAr=(DLOG10(Armax)-DLOG10(Ar(1)))/NP

* Define the logical variable that will let the program leave the
* DO loop at the right time, and initialize dAr.

      NOTDONE=.TRUE.

* Begin the DO loop.

      DO WHILE (NOTDONE)

* If Ar gets to be the maximum, then we're done. (hence the IF statement
* below).

         IF(Ar(Jr).GE.0.999999d0*Armax) NOTDONE=.FALSE.

* We must do a loop over each parent star.

         DO K=1,N
            DO WHILE (As(Jp(K),K).LE.Ar(Jr) .AND. Jp(K).LE.Pmax(K))
               Jp(K)=Jp(K)+1
            ENDDO
            IF(As(Pmax(K),K).LE.Ar(Jr) .AND. 
     &           As(Pmax(K),K).GE.Ar(Jr)-1.d-06) THEN
               Jp(K)=Pmax(K)
            ENDIF

            IF(Jp(K).GE.2 .AND. Jp(K).LE.Pmax(K)) THEN
               dAsdMp(K)=(As(Jp(K),K)-As(Jp(K)-1,K))/
     &              (Mp(Jp(K),K)-Mp(Jp(K)-1,K))
               MofAr(K)=(Ar(Jr)-As(Jp(K)-1,K))*Mp(Jp(K),K)/(As(Jp(K),K)-
     &              As(Jp(K)-1,K))+(As(Jp(K),K)-Ar(Jr))*Mp(Jp(K)-1,K)/
     &              (As(Jp(K),K)-As(Jp(K)-1,K))
               dArp(K)=As(Jp(K),K)-As(Jp(K)-1,K)
               DO C=1,el
                  Chem(C,K)=(Ar(Jr)-As(Jp(K)-1,K))*ELm(Jp(K),C,K)/
     &                 (As(Jp(K),K)-As(Jp(K)-1,K))+(As(Jp(K),K)-Ar(Jr))
     &                 *ELm(Jp(K)-1,C,K)/(As(Jp(K),K)-As(Jp(K)-1,K))
               ENDDO
            ELSE IF(Jp(K).EQ.1) THEN
               dAsdMp(K)=1.d30
               DO C=1,el
                  Chem(C,K)=0.d0
               ENDDO
               dArp(K)=1.d30
               MofAr(K)=0.d0
            ELSE IF(Jp(K).GT.Pmax(K)) THEN
               dAsdMp(K)=1.d30
               DO C=1,el
                  Chem(C,K)=0.d0
               ENDDO
               dArp(K)=1.d30
               MofAr(K)=Mp(Pmax(K),K)
            ENDIF
         ENDDO

         dAdMtmp=0.d0
         DO C=1,el
            Chemtmp(C)=0.d0
         ENDDO
         Mtmp=0.d0
         dArtmp=1.d30
         DO K=1,N
            dAdMtmp=1.d0/dAsdMp(K)+dAdMtmp
            DO C=1,el
               Chemtmp(C)=Chem(C,K)/dAsdMp(K)+Chemtmp(C)
            ENDDO
            Mtmp=MofAr(K)+Mtmp
            dArtmp=1.d0*min(dArp(K),dArtmp)
         ENDDO

         dArdMr=dAdMtmp**(-1.d0)
         DO C=1,el
            ELr(Jr,C)=dArdMr*Chemtmp(C)
         ENDDO
         Mr(Jr)=Mtmp

         IF(NP.lt.0) then
C Use the smallest reasonable dAr if NP<0 : 
            dAr=dArtmp
         else

            dAr=dArdMr*(Mp(Pmax(1),1)+Mp(Pmax(2),2))/(NP-3.5d0)

C These lines of data will have the *logarithm*
C of the entropic variable A spaced regularly...
c         dAr=10.d0**(DLOG10(Ar(Jr))+dlogAr)-Ar(Jr)

         endif

         IF(Ar(Jr)+dAr.GE.0.999999d0*Armax) THEN
            dAr=Armax-Ar(Jr)
         ENDIF       

         Jr=Jr+1
         Ar(Jr)=Ar(Jr-1)+dAr

         IF(Jr.GT.NROWS) THEN
            print *, 'WARNING!  You may need to increase NROWS in'
            print *, 'the header file.  NROWS=',NROWS
            STOP
         ENDIF

      ENDDO

      Jrmax=Jr-1

      END
*******************************************************************
      SUBROUTINE zbrak(fx,x1,x2,n,xb1,xb2,nb)
      implicit none
      INTEGER n,nb
      DOUBLE PRECISION x1,x2,xb1(nb),xb2(nb),fx
      EXTERNAL fx
      INTEGER i,nbb
      DOUBLE PRECISION dx,fc,fp,x
      nbb=0
      x=x1
      dx=(x2-x1)/n
      fp=fx(x)
      do 11 i=1,n
        x=x+dx
        fc=fx(x)
        if(fc*fp.lt.0.d0) then
          nbb=nbb+1
          xb1(nbb)=x-dx
          xb2(nbb)=x
          if(nbb.eq.nb)goto 1
        endif
        fp=fc
11    continue
1     continue
      nb=nbb
      return
      END
